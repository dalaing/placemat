# Layout timings: `/private/tmp/claude-501/-Users-dave-work-ngn-k-k/eb2f95d5-4068-4d95-8225-d12e510d750c/scratchpad/of/K2` against `/private/tmp/claude-501/-Users-dave-work-ngn-k-k/eb2f95d5-4068-4d95-8225-d12e510d750c/scratchpad/of/C2`

## Layout-randomised timings

Each case re-timed across 6 layout variants of base and of branch: the same source with an unused
function of P bytes at the top of `src/0.c`, P = 576, 1256, 1940, 2624, 3304, 3988 (seed 0),
which moves the code after it through a 4 KB period as unrelated edits elsewhere would.
Variant i of base and of branch run back to back (random order), 7 rounds after a warm-up,
and the stock (unpadded) builds as one more pair: their change and interval are the Stock layout
column (** when measurable), the layout the normal pass timed.
Change: geometric mean over variants of the median paired ratio branch/base, with a two-level
bootstrap 95% interval (variants, then rounds). Spread: range / SD of a version's variant medians
relative to their median; **sens.** marks layout sensitivity (range over the threshold of 3%, 10% under
5 ms, and p < 0.01 when the variant labels are permuted within rounds). Outliers: Tukey fences within each
version and variant. (series): a case under 1 ms a call, timed at 1/8, 1/4, 1/2 and 1 times its
repetitions and taken as the least-squares slope. Verdict: **change** when the interval excludes
no change and the change is over the threshold; otherwise placement when the stock layout's change
is measurable or a version is layout-sensitive, else noise.

| Case | Stock layout | Layout-averaged change | 95% interval | Base spread | Branch spread | Outliers | Verdict |
|---|---|---|---|---|---|---|---|
| `microbench: grade` | +0.9% (-1.9% to +3.4%) | +1.1% | -1.7% to +3.4% | 3.6% / 1.2% | 2.3% / 0.9% | 4/98 | noise |
| `microbench: igradedown` | +2.6% (+0.9% to +5.4%) | +0.5% | -0.8% to +2.2% | 2.3% / 0.9% | 2.8% / 1.0% | 2/98 | noise |
| `microbench: setdictnest` (series) | +3.9% (+2.6% to +4.8%) ** | +5.5% | +3.9% to +7.4% | 4.8% / 1.9% | 2.3% / 1.0% | 1/98 | **change** |
| `microbench: setdictall` (series) | +1.9% (+0.4% to +3.8%) | +3.1% | +1.5% to +4.4% | 1.3% / 0.5% | 3.5% / 1.3% | 1/98 | **change** |
| `microbench: setlistdictall` (series) | +3.3% (+2.0% to +3.5%) ** | +2.0% | +1.4% to +2.6% | 0.9% / 0.3% | 1.5% / 0.7% | 3/98 | placement |
| `microbench: setdictverb` (series) | +3.7% (-0.2% to +4.9%) | +4.6% | +2.6% to +5.6% | 2.5% / 0.9% | 2.2% / 0.8% | 2/98 | **change** |
| `microbench: settableverb` (series) | +1.9% (+0.8% to +4.2%) | +3.6% | +2.1% to +5.1% | 1.3% / 0.5% | 2.2% / 0.9% | 2/98 | **change** |
| `microbench: jsonshort` (series) | -0.6% (-2.7% to +1.1%) | +0.6% | -1.6% to +2.4% | 2.6% / 1.0% | 4.4% / 1.8% | 2/98 | noise |
| `microbench: dategrade` (series) | -0.2% (-2.8% to +2.9%) | +0.0% | -2.7% to +2.1% | 4.4% / 1.6% | 3.1% / 1.1% | 4/98 | noise |
| `microbench: stampgrade` (series) | +0.8% (-9.7% to +1.3%) | +1.2% | -1.4% to +2.8% | 1.6% / 0.7% | 3.8% / 1.3% | 2/98 | noise |

<details><summary>Variants</summary>

Shift: the most common move of a function against the unpadded build (mod 4096), and the share of
functions that did not move (an order file's pinned functions; the code before the pad). Loops: small
loops straddling a 4 KB boundary.

| Variant | Pad | Base shift | Branch shift | Base loops | Branch loops | microbench: grade base / branch | microbench: igradedown base / branch | microbench: setdictnest base / branch | microbench: setdictall base / branch | microbench: setlistdictall base / branch | microbench: setdictverb base / branch | microbench: settableverb base / branch | microbench: jsonshort base / branch | microbench: dategrade base / branch | microbench: stampgrade base / branch |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | 576 | 592 (17.4% unmoved) | 592 (17.1% unmoved) | 66 | 43 | 35722 / 36017 | 39492 / 40192 | 17914 / 18864 | 36123 / 37813 | 112435 / 115389 | 20176 / 20913 | 23204 / 23719 | 8702 / 8642 | 1279 / 1267 | 1734 / 1711 |
| 1 | 1256 | 1264 (17.4% unmoved) | 1264 (17.1% unmoved) | 65 | 61 | 36218 / 36588 | 39467 / 39552 | 18151 / 18605 | 36463 / 38021 | 112580 / 115233 | 20504 / 21037 | 23011 / 24255 | 8563 / 8609 | 1264 / 1295 | 1708 / 1755 |
| 2 | 1940 | 1952 (17.4% unmoved) | 1952 (17.1% unmoved) | 51 | 51 | 36043 / 35929 | 40057 / 40306 | 17407 / 18559 | 36614 / 36701 | 112067 / 113635 | 20231 / 20847 | 22937 / 23731 | 8737 / 8634 | 1281 / 1256 | 1707 / 1731 |
| 3 | 2624 | 2640 (17.4% unmoved) | 2640 (17.1% unmoved) | 66 | 56 | 35424 / 36083 | 39611 / 39836 | 17937 / 18862 | 36570 / 37621 | 112017 / 115418 | 20142 / 21017 | 22954 / 23765 | 8785 / 8645 | 1299 / 1272 | 1729 / 1710 |
| 4 | 3304 | 3312 (17.4% unmoved) | 3312 (17.1% unmoved) | 51 | 50 | 36137 / 36476 | 39847 / 40679 | 17288 / 18997 | 36304 / 37981 | 113000 / 115247 | 19991 / 21305 | 22913 / 24008 | 8621 / 8836 | 1252 / 1262 | 1722 / 1715 |
| 5 | 3988 | 4000 (17.4% unmoved) | 4000 (17.1% unmoved) | 55 | 43 | 36734 / 35745 | 40386 / 40054 | 17698 / 18620 | 36541 / 38012 | 112455 / 114005 | 20302 / 20957 | 23119 / 24114 | 8613 / 8992 | 1242 / 1270 | 1711 / 1689 |
| stock | - | 0 (100.0% unmoved) | 0 (100.0% unmoved) | 57 | 49 | 35671 / 36548 | 39457 / 40818 | 18108 / 18986 | 35965 / 36614 | 111927 / 115284 | 20442 / 21139 | 23563 / 23882 | 8611 / 8559 | 1269 / 1256 | 1737 / 1704 |

Builds and checks 58 s; timings 123 s; load 2.94 at start, 2.92 at end.

</details>

