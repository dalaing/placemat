
## Layout-randomised timings (designed: code and data)

Each case re-timed across designed variants of base and of branch (pbt/ldesign.py, seed 0). Pad j (an unused
function at the top of `src/0.c`) is built once and timed twice: at the stock data placement (colour 0) and at a
designed colour C_j (`AMBER_COLOUR`, a fork-only hook in the variant builds' `src/m.c`: each block of 64 KB or
more moved c*(k+1) mod 16 KB into its slot); pads and colours are one 2-D Kronecker sequence. Base and branch of
a variant run back to back (random order), 7 rounds after a first run of each; the stock (unpadded, unhooked)
builds as one more pair in the first batch (Stock layout; ** when measurable), and variant 0 again in each later
batch (an anchor). Adaptive: 8 variants, then 4 more at a time while the interval is wider than +-1.0%, up to
24.

Change: geometric mean of the per-variant median paired ratios branch/base (per pad first), with a t interval
over the pads (pads - 1 df); Stock data and Designed data: the same over each half alone. Code: the range of the
stock-data variants' medians (base / branch; later batches scaled by their anchor), the slowest against their
median (the worse version), and the case's p-value (labels permuted within a batch's rounds, statistic the
within-batch sum of squares of trimmed means; the smaller of base's and branch's, doubled). Data: how much
slower the stock data placement is than the designed one (stock / designed - 1 per pad: the median over the
pads, base / branch, and the largest either way), and the p-value (sign-flip permutation within rounds).
**code** / **data**: significant after Benjamini-Hochberg across the cases (q = 0.05), p <= 0.01, and over the
threshold (3%, 10% under 5 ms). Spread: the range of all variant medians. Run: the run-to-run region base (ASLR)
at its most common address or not, the largest change it makes at one colour (max-|z| permutation test over the
colours, labels permuted within variants); when p < 0.05 each run is adjusted for it, per colour, for the tests,
and each variant's change is taken within categories (post-stratified). Verdict: **change** when the interval
excludes no change and the change is over the threshold; otherwise placement when the stock change is measurable
or the case is flagged; noise otherwise; data-dependent when the stock-data and designed-data changes differ
(paired t over pads, p < 0.01, over the threshold). Attributed "stock code layout": the stock pair's change is
measurable and its interval misses the stock-data variants' (they differ from it in code only: no pad, no hook,
the same data placement).

Flagged (of 6 cases): code 1, data 0, run 0; change 1, data-dependent 0; stock code layout 2; intervals containing no change: 3.

| Case | Stock layout | Layout-averaged change | 95% interval | K | Stock data | Designed data | Code | Data | Spread | Run | Attributed | Verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| `microbench: grade` | +8.3% (+6.6% to +11.8%) ** | +0.2% | -0.8% to +1.2% | 24 | +0.1% (-1.4% to +1.6%) | +0.3% (-0.8% to +1.4%) | 3.2% / 1.5%, worst +6.5% (p 1) | -0.2% / -0.1%, max 3.0% (p 1) | 3.7% / 3.2% | (p 1) | stock code layout | placement |
| `microbench: igradedown` | +10.3% (+9.8% to +13.7%) ** | -0.7% | -1.6% to +0.2% | 12 | -1.2% (-2.8% to +0.5%) | -0.2% (-1.2% to +0.8%) | 2.3% / 4.5%, worst +4.4% (p 0.11) | +0.2% / -0.9%, max 4.4% (p 0.96) | 2.5% / 4.5% | (p 1) | stock code layout | placement |
| `microbench: setdictnest` (series) | +5.1% (+1.7% to +12.3%) ** | +5.3% | +3.9% to +6.7% | 24 | +4.6% (+2.9% to +6.4%) | +6.0% (+4.7% to +7.3%) | 4.2% / 4.2%, worst +7.5% (p 0.011) | +1.5% / +0.3%, max 3.9% (p 0.047) | 7.3% / 4.4% | (p 0.56) | - | **change** |
| `microbench: setdictall` (series) | +5.7% (-0.3% to +7.0%) | +3.0% | +2.1% to +3.9% | 24 | +3.2% (+2.3% to +4.2%) | +2.7% (+1.7% to +3.8%) | 4.8% / 3.0%, worst +9.6% (p 0.38) | +0.2% / -0.1%, max 2.7% (p 1) | 6.2% / 3.0% | (p 0.35) | - | noise |
| `microbench: setlistdictall` (series) | +3.7% (+1.9% to +4.6%) ** | +2.2% | +1.4% to +3.0% | 16 | +2.2% (+1.6% to +2.9%) | +2.2% (+1.3% to +3.1%) | 4.5% / 3.8%, worst +5.8% (p 0.0085) **code** | +0.0% / +0.1%, max 2.5% (p 0.09) | 4.5% / 4.0% | (p 0.2) | code | placement |
| `microbench: fsum` (series) | -0.0% (-4.8% to +1.7%) | +0.0% | -0.6% to +0.7% | 12 | +0.4% (-1.0% to +1.8%) | -0.3% (-0.6% to +0.0%) | 3.1% / 3.5%, worst +3.5% (p 0.067) | -1.6% / -0.2%, max 3.2% (p 0.15) | 3.5% / 3.5% | (p 1) | - | noise |

<details><summary>Design and variants</summary>

12 pads: 76, 364, 696, 1316, 1712, 1872, 2268, 2664, 2824, 3220, 3508, 3776; largest gap mod 4096 620 B (even: 341); 12 of 16 phases mod 64, 4 of 4 mod 16.
12 designed colours (and 0, the stock placement): 48, 1184, 2832, 4016, 5136, 6800, 7984, 9632, 10752, 12416, 13600, 14720; largest gap mod 16384 1664 B (even: 1260); 4 of 4 phases mod 64.

Shift: the most common move of a function against the pad-0 variant build (mod 4096) and the share of
functions not moved (an order file's pinned region); Loops: small loops straddling a 4 KB boundary.

| Variant | Pad | Colour | Base shift | Branch shift | Base loops | Branch loops | microbench: grade base / branch | microbench: igradedown base / branch | microbench: setdictnest base / branch | microbench: setdictall base / branch | microbench: setlistdictall base / branch | microbench: fsum base / branch |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | 3508 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 38412 / 38075 | 42595 / 40490 | 19075 / 20648 | 39049 / 39725 | 120932 / 125989 | 23859 / 24682 |
| 1 | 3508 | 12416 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 38681 / 38369 | 41908 / 41274 | 18727 / 20182 | 39065 / 39835 | 122854 / 125489 | 24223 / 23928 |
| 2 | 1872 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 38212 / 37828 | 42248 / 42248 | 18343 / 20170 | 40441 / 40808 | 123329 / 123954 | 24592 / 24140 |
| 3 | 1872 | 2832 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 38078 / 37894 | 41645 / 41449 | 17876 / 20298 | 39391 / 39832 | 120272 / 121196 | 24161 / 23871 |
| 4 | 364 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 37844 / 38065 | 41643 / 41819 | 19106 / 20239 | 38668 / 40078 | 118084 / 121520 | 23917 / 23848 |
| 5 | 364 | 9632 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 38405 / 38622 | 41883 / 41940 | 19218 / 20591 | 38139 / 40350 | 118863 / 121571 | 24658 / 23918 |
| 6 | 2824 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 39012 / 37529 | 41737 / 40424 | 18893 / 19838 | 38757 / 39680 | 120822 / 124678 | 24277 / 23850 |
| 7 | 2824 | 48 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 38333 / 38705 | 41537 / 42268 | 19203 / 19798 | 38704 / 40704 | 119691 / 125553 | 24696 / 24000 |
| 8 | 1316 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 35867 / 36434 | 39818 / 40150 | 18436 / 18772 | 36359 / 36980 | 115135 / 116784 | 22893 / 23056 |
| 9 | 1316 | 6800 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 35793 / 36079 | 39853 / 39939 | 17752 / 18776 | 36354 / 37230 | 114773 / 115920 | 22807 / 23061 |
| 10 | 3776 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 35710 / 36065 | 39747 / 39735 | 18005 / 18597 | 36095 / 37859 | 112955 / 115460 | 22875 / 22842 |
| 11 | 3776 | 13600 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 36740 / 35854 | 40057 / 40311 | 17748 / 18235 | 35737 / 37282 | 113372 / 115161 | 23342 / 23116 |
| 12 | 2268 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 35965 / 36975 | | 18608 / 19220 | 36389 / 38059 | 113370 / 115479 | |
| 13 | 2268 | 4016 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 35600 / 37196 | | 18333 / 19111 | 36665 / 38053 | 112709 / 115751 | |
| 14 | 696 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 35584 / 36804 | | 18261 / 19212 | 36553 / 37859 | 113402 / 115904 | |
| 15 | 696 | 10752 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 35804 / 36406 | | 17773 / 18836 | 37033 / 37336 | 113761 / 116347 | |
| 16 | 3220 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 36806 / 36491 | | 18438 / 19357 | 36445 / 37894 | | |
| 17 | 3220 | 1184 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 37088 / 35567 | | 18324 / 19291 | 36654 / 37856 | | |
| 18 | 1712 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 36260 / 36057 | | 18557 / 19023 | 36943 / 37569 | | |
| 19 | 1712 | 7984 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 35723 / 35562 | | 18352 / 18924 | 36881 / 37296 | | |
| 20 | 76 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 36455 / 36497 | | 18539 / 18756 | 36841 / 37272 | | |
| 21 | 76 | 14720 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 36886 / 37010 | | 18206 / 18850 | 36508 / 37356 | | |
| 22 | 2664 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 36950 / 36637 | | 17789 / 18386 | 37005 / 37306 | | |
| 23 | 2664 | 5136 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 36263 / 36658 | | 17681 / 18868 | 36563 / 37648 | | |
| stock | - | - | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 38868 / 41651 | 42339 / 46816 | 19290 / 20385 | 37917 / 40543 | 118310 / 123948 | 24020 / 23955 |

Region base: most common 0x300000000 in 45% of the first case's base runs.

</details>

