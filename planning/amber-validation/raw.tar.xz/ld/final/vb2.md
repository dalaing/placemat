
## Layout-randomised timings (designed: code and data)

Each case re-timed across designed variants of base and of branch (pbt/ldesign.py, seed 0). Pad j (an unused
function at the top of `src/0.c`) is built once and timed twice: at the stock data placement (colour 0) and at a
designed colour C_j (`AMBER_COLOUR`, a fork-only hook in the variant builds' `src/m.c`: each block of 64 KB or
more moved c*(k+1) mod 16 KB into its slot); pads and colours are one 2-D Kronecker sequence. Base and branch of
a variant run back to back (random order), 7 rounds after a first run of each; the stock (unpadded, unhooked)
builds as one more pair in the first batch (Stock layout; ** when measurable), and variant 0 again in each later
batch (an anchor). Adaptive: 8 variants, then 4 more at a time while the interval is wider than +-1.0%, up to
24.

Change: geometric mean of the per-variant median paired ratios branch/base (per pad first), with a t interval
over the pads (pads - 1 df); Stock data and Designed data: the same over each half alone. Code: the range of the
stock-data variants' medians (base / branch; later batches scaled by their anchor), the slowest against their
median (the worse version), and the case's p-value (labels permuted within a batch's rounds, statistic the
within-batch sum of squares of trimmed means; the smaller of base's and branch's, doubled). Data: how much
slower the stock data placement is than the designed one (stock / designed - 1 per pad: the median over the
pads, base / branch, and the largest either way), and the p-value (sign-flip permutation within rounds).
**code** / **data**: significant after Benjamini-Hochberg across the cases (q = 0.05), p <= 0.01, and over the
threshold (3%, 10% under 5 ms). Spread: the range of all variant medians. Run: the run-to-run region base (ASLR)
at its most common address or not, the largest change it makes at one colour (max-|z| permutation test over the
colours, labels permuted within variants); when p < 0.05 each run is adjusted for it, per colour, for the tests,
and each variant's change is taken within categories (post-stratified). Verdict: **change** when the interval
excludes no change and the change is over the threshold; otherwise placement when the stock change is measurable
or the case is flagged; noise otherwise; data-dependent when the stock-data and designed-data changes differ
(paired t over pads, p < 0.01, over the threshold). Attributed "stock code layout": the stock pair's change is
measurable and its interval misses the stock-data variants' (they differ from it in code only: no pad, no hook,
the same data placement).

Flagged (of 6 cases): code 2, data 0, run 0; change 2, data-dependent 0; stock code layout 3; intervals containing no change: 3.

| Case | Stock layout | Layout-averaged change | 95% interval | K | Stock data | Designed data | Code | Data | Spread | Run | Attributed | Verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| `microbench: grade` | +11.1% (+10.3% to +13.2%) ** | +0.5% | -0.4% to +1.3% | 24 | +0.4% (-1.2% to +1.9%) | +0.6% (-1.1% to +2.3%) | 8.4% / 5.9%, worst +3.3% (p 0.1) | +1.1% / -0.4%, max 5.3% (p 0.71) | 8.5% / 7.0% | (p 0.81) | stock code layout | placement |
| `microbench: igradedown` | +11.5% (+8.4% to +13.4%) ** | -0.0% | -0.2% to +0.2% | 8 | -0.2% (-1.6% to +1.2%) | +0.2% (-1.4% to +1.7%) | 2.6% / 1.0%, worst +0.9% (p 0.91) | +1.5% / -0.7%, max 3.8% (p 0.35) | 3.8% / 1.6% | (p 0.57) | stock code layout | placement |
| `microbench: setdictnest` (series) | +4.2% (+2.2% to +4.7%) ** | +5.8% | +3.9% to +7.7% | 24 | +5.9% (+4.0% to +7.7%) | +5.7% (+3.6% to +7.9%) | 6.9% / 4.3%, worst +2.5% (p 0.0011) **code** | +0.5% / +0.8%, max 5.9% (p 0.069) | 7.6% / 5.8% | (p 0.77) | code | **change** |
| `microbench: setdictall` (series) | +7.2% (+5.7% to +8.4%) ** | +3.1% | +2.2% to +4.0% | 24 | +3.1% (+2.1% to +4.2%) | +3.1% (+2.1% to +4.0%) | 4.4% / 2.5%, worst +3.0% (p 0.017) | -0.1% / -0.1%, max 2.2% (p 0.52) | 4.4% / 2.8% | (p 0.75) | stock code layout | **change** |
| `microbench: setlistdictall` (series) | +2.7% (+2.3% to +4.0%) | +2.2% | +1.3% to +3.1% | 20 | +2.3% (+1.4% to +3.2%) | +2.1% (+1.2% to +3.0%) | 2.5% / 3.4%, worst +2.8% (p 0.0001) **code** | -0.0% / +0.4%, max 1.3% (p 1) | 2.6% / 3.7% | (p 0.82) | code | placement |
| `microbench: fsum` (series) | +1.6% (-2.1% to +1.9%) | +0.0% | -0.5% to +0.6% | 8 | -0.2% (-1.5% to +1.1%) | +0.3% (-0.5% to +1.1%) | 3.5% / 2.2%, worst +2.4% (p 0.055) | +0.4% / -0.3%, max 3.6% (p 0.18) | 3.6% / 2.2% | (p 1) | - | noise |

<details><summary>Design and variants</summary>

12 pads: 76, 364, 696, 1316, 1712, 1872, 2268, 2664, 2824, 3220, 3508, 3776; largest gap mod 4096 620 B (even: 341); 12 of 16 phases mod 64, 4 of 4 mod 16.
12 designed colours (and 0, the stock placement): 48, 1184, 2832, 4016, 5136, 6800, 7984, 9632, 10752, 12416, 13600, 14720; largest gap mod 16384 1664 B (even: 1260); 4 of 4 phases mod 64.

Shift: the most common move of a function against the pad-0 variant build (mod 4096) and the share of
functions not moved (an order file's pinned region); Loops: small loops straddling a 4 KB boundary.

| Variant | Pad | Colour | Base shift | Branch shift | Base loops | Branch loops | microbench: grade base / branch | microbench: igradedown base / branch | microbench: setdictnest base / branch | microbench: setdictall base / branch | microbench: setlistdictall base / branch | microbench: fsum base / branch |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | 3508 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 35376 / 35354 | 39775 / 39614 | 17531 / 19504 | 36954 / 38215 | 114435 / 119741 | 22921 / 23146 |
| 1 | 3508 | 12416 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 35434 / 37351 | 39353 / 39617 | 18178 / 19404 | 36927 / 38165 | 114888 / 119092 | 23263 / 23094 |
| 2 | 1872 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 34994 / 36145 | 39287 / 39411 | 17212 / 19038 | 38085 / 38097 | 116035 / 115800 | 22891 / 23121 |
| 3 | 1872 | 2832 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 36519 / 36073 | 39838 / 39871 | 16943 / 18706 | 37841 / 37785 | 115392 / 116151 | 23044 / 23321 |
| 4 | 364 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 35547 / 36827 | 40129 / 39702 | 18015 / 18903 | 37231 / 38636 | 113229 / 117359 | 23371 / 22936 |
| 5 | 364 | 9632 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 34955 / 35585 | 39403 / 39933 | 17990 / 18671 | 36573 / 38644 | 113110 / 116419 | 23054 / 23140 |
| 6 | 2824 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 36611 / 36297 | 40303 / 39318 | 17729 / 19101 | 36796 / 38130 | 115471 / 118297 | 23698 / 23455 |
| 7 | 2824 | 48 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 34773 / 35133 | 38810 / 39618 | 17826 / 19291 | 36947 / 38260 | 115661 / 116809 | 22873 / 23217 |
| 8 | 1316 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 35167 / 35405 | | 18340 / 18925 | 36285 / 37051 | 114393 / 116107 | |
| 9 | 1316 | 6800 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 36307 / 35728 | | 17821 / 19198 | 36350 / 36945 | 114765 / 115693 | |
| 10 | 3776 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 35370 / 35513 | | 18151 / 18486 | 36266 / 37378 | 113491 / 115597 | |
| 11 | 3776 | 13600 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 34791 / 35462 | | 17951 / 18342 | 35920 / 37823 | 113430 / 115185 | |
| 12 | 2268 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 35083 / 35492 | | 18121 / 18992 | 36244 / 37689 | 112970 / 115349 | |
| 13 | 2268 | 4016 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 34811 / 35709 | | 17949 / 19260 | 36451 / 37991 | 112799 / 115477 | |
| 14 | 696 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 35678 / 35132 | | 17733 / 18804 | 35620 / 37605 | 113159 / 115730 | |
| 15 | 696 | 10752 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 34607 / 36653 | | 17762 / 18579 | 36424 / 37775 | 113400 / 115283 | |
| 16 | 3220 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 36319 / 34995 | | 18569 / 19024 | 36838 / 37231 | 114407 / 116075 | |
| 17 | 3220 | 1184 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 35400 / 35410 | | 17536 / 19122 | 36341 / 37541 | 113896 / 115742 | |
| 18 | 1712 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 34449 / 36157 | | 18419 / 18661 | 36458 / 37628 | 112572 / 116053 | |
| 19 | 1712 | 7984 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 35330 / 34886 | | 18480 / 18451 | 36647 / 37221 | 112694 / 116632 | |
| 20 | 76 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 34333 / 34334 | | 18289 / 19236 | 36514 / 37691 | | |
| 21 | 76 | 14720 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 34954 / 35498 | | 18184 / 19006 | 36498 / 37777 | | |
| 22 | 2664 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 35564 / 35591 | | 17600 / 19331 | 36781 / 37827 | | |
| 23 | 2664 | 5136 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 35065 / 35624 | | 17512 / 19189 | 37059 / 37723 | | |
| stock | - | - | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 35454 / 39475 | 39561 / 44118 | 18248 / 19019 | 35946 / 38459 | 112688 / 115069 | 22949 / 23260 |

Region base: most common 0x300000000 in 41% of the first case's base runs.

</details>

