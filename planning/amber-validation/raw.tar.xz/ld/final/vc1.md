
## Layout-randomised timings (designed: code and data)

Each case re-timed across designed variants of base and of branch (pbt/ldesign.py, seed 0). Pad j (an unused
function at the top of `src/0.c`) is built once and timed twice: at the stock data placement (colour 0) and at a
designed colour C_j (`AMBER_COLOUR`, a fork-only hook in the variant builds' `src/m.c`: each block of 64 KB or
more moved c*(k+1) mod 16 KB into its slot); pads and colours are one 2-D Kronecker sequence. Base and branch of
a variant run back to back (random order), 7 rounds after a first run of each; the stock (unpadded, unhooked)
builds as one more pair in the first batch (Stock layout; ** when measurable), and variant 0 again in each later
batch (an anchor). Adaptive: 8 variants, then 4 more at a time while the interval is wider than +-1.0%, up to
24.

Change: geometric mean of the per-variant median paired ratios branch/base (per pad first), with a t interval
over the pads (pads - 1 df); Stock data and Designed data: the same over each half alone. Code: the range of the
stock-data variants' medians (base / branch; later batches scaled by their anchor), the slowest against their
median (the worse version), and the case's p-value (labels permuted within a batch's rounds, statistic the
within-batch sum of squares of trimmed means; the smaller of base's and branch's, doubled). Data: how much
slower the stock data placement is than the designed one (stock / designed - 1 per pad: the median over the
pads, base / branch, and the largest either way), and the p-value (sign-flip permutation within rounds).
**code** / **data**: significant after Benjamini-Hochberg across the cases (q = 0.05), p <= 0.01, and over the
threshold (3%, 10% under 5 ms). Spread: the range of all variant medians. Run: the run-to-run region base (ASLR)
at its most common address or not, the largest change it makes at one colour (max-|z| permutation test over the
colours, labels permuted within variants); when p < 0.05 each run is adjusted for it, per colour, for the tests,
and each variant's change is taken within categories (post-stratified). Verdict: **change** when the interval
excludes no change and the change is over the threshold; otherwise placement when the stock change is measurable
or the case is flagged; noise otherwise; data-dependent when the stock-data and designed-data changes differ
(paired t over pads, p < 0.01, over the threshold). Attributed "stock code layout": the stock pair's change is
measurable and its interval misses the stock-data variants' (they differ from it in code only: no pad, no hook,
the same data placement).

Flagged (of 6 cases): code 0, data 5, run 3; change 0, data-dependent 0; stock code layout 0; intervals containing no change: 6.

| Case | Stock layout | Layout-averaged change | 95% interval | K | Stock data | Designed data | Code | Data | Spread | Run | Attributed | Verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| `win.k: s_msum100` | -0.5% (-32.1% to +38.8%) | -0.9% | -5.3% to +3.8% | 24 | -2.3% (-11.2% to +7.5%) | +0.6% (-0.1% to +1.3%) | 53.0% / 50.1%, worst +17.4% (p 1) | +134.2% / +147.2%, max 176.9% (p 0.0001) **data** | 119.1% / 120.6% | (p 0.14) | data | placement |
| `win.k: s_mavg100` | -0.2% (-34.1% to +50.3%) | -1.3% | -6.4% to +4.0% | 24 | -2.7% (-12.8% to +8.6%) | +0.0% (-0.7% to +0.7%) | 61.0% / 61.8%, worst +20.8% (p 1) | +139.4% / +141.0%, max 190.3% (p 0.0001) **data** | 128.3% / 129.0% | (p 0.059) | data | placement |
| `win.k: s_mdev100` | +0.7% (-22.2% to +31.5%) | +0.4% | -1.1% to +1.9% | 24 | +0.8% (-1.9% to +3.5%) | +0.0% (-0.7% to +0.7%) | 8.7% / 4.4%, worst +6.9% (p 1) | +36.6% / +41.2%, max 48.7% (p 0.0001) **data** | 38.2% / 40.2% | +43.7% at colour 0 (p 0.0001) **run**, adjusted | data+run | placement |
| `win.k: s_mmin100` | -0.6% (-1.4% to +1.1%) | +0.1% | -0.4% to +0.7% | 8 | +0.5% (-0.7% to +1.7%) | -0.2% (-1.7% to +1.2%) | 2.0% / 1.5%, worst +1.8% (p 0.022) | -1.0% / -0.1%, max 3.2% (p 0.032) | 3.3% / 2.2% | (p 0.74) | - | noise |
| `win.k: s_mavg10` | -1.7% (-32.1% to +45.9%) | +0.5% | -1.7% to +2.7% | 24 | +1.4% (-2.9% to +5.9%) | -0.4% (-1.3% to +0.5%) | 17.7% / 14.7%, worst +12.8% (p 1) | +69.1% / +78.5%, max 102.2% (p 0.0001) **data** | 67.3% / 74.3% | +70.5% at colour 0 (p 0.0001) **run**, adjusted | data+run | placement |
| `win.k: s_mavg1000` | +0.2% (-31.6% to +39.2%) | +0.1% | -1.7% to +2.1% | 24 | +0.6% (-2.8% to +4.2%) | -0.3% (-1.4% to +0.7%) | 16.4% / 8.0%, worst +13.3% (p 1) | +54.9% / +61.5%, max 76.7% (p 0.0001) **data** | 59.7% / 57.9% | +59.1% at colour 0 (p 0.0001) **run**, adjusted | data+run | placement |

<details><summary>Design and variants</summary>

12 pads: 76, 364, 696, 1316, 1712, 1872, 2268, 2664, 2824, 3220, 3508, 3776; largest gap mod 4096 620 B (even: 341); 12 of 16 phases mod 64, 4 of 4 mod 16.
12 designed colours (and 0, the stock placement): 48, 1184, 2832, 4016, 5136, 6800, 7984, 9632, 10752, 12416, 13600, 14720; largest gap mod 16384 1664 B (even: 1260); 4 of 4 phases mod 64.

Shift: the most common move of a function against the pad-0 variant build (mod 4096) and the share of
functions not moved (an order file's pinned region); Loops: small loops straddling a 4 KB boundary.

| Variant | Pad | Colour | Base shift | Branch shift | Base loops | Branch loops | win.k: s_msum100 base / branch | win.k: s_mavg100 base / branch | win.k: s_mdev100 base / branch | win.k: s_mmin100 base / branch | win.k: s_mavg10 base / branch | win.k: s_mavg1000 base / branch |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | 3508 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 16676 / 16868 | 23071 / 22873 | 38757 / 38818 | 21870 / 21937 | 22765 / 22430 | 25784 / 25655 |
| 1 | 3508 | 12416 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 8421 / 8743 | 11487 / 11837 | 26073 / 26485 | 21925 / 21804 | 11305 / 11248 | 15184 / 14742 |
| 2 | 1872 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 16828 / 17133 | 23182 / 23937 | 38932 / 40318 | 21794 / 21928 | 22448 / 23790 | 25635 / 27387 |
| 3 | 1872 | 2832 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 8617 / 8428 | 11534 / 11462 | 26034 / 26583 | 22515 / 22102 | 11699 / 11301 | 14883 / 15066 |
| 4 | 364 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 23336 / 23047 | 33398 / 33382 | 51988 / 51489 | 21820 / 22257 | 33005 / 33410 | 36193 / 36444 |
| 5 | 364 | 9632 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 8545 / 8563 | 11744 / 11499 | 26571 / 26169 | 22113 / 22102 | 11365 / 11381 | 14933 / 14938 |
| 6 | 2824 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 16668 / 22681 | 22980 / 33187 | 39316 / 51042 | 22242 / 22011 | 23397 / 32686 | 26340 / 36398 |
| 7 | 2824 | 48 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 8513 / 8418 | 11764 / 11583 | 26371 / 26784 | 22381 / 22298 | 11553 / 11577 | 14866 / 15248 |
| 8 | 1316 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 22872 / 23161 | 33177 / 33061 | 51535 / 50663 | | 32775 / 32905 | 36343 / 36510 |
| 9 | 1316 | 6800 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 8446 / 8697 | 11506 / 11526 | 26267 / 26099 | | 11508 / 11546 | 14897 / 14830 |
| 10 | 3776 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 22512 / 23005 | 33123 / 33290 | 50735 / 51068 | | 33218 / 32816 | 36423 / 36428 |
| 11 | 3776 | 13600 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 8558 / 8407 | 11455 / 11538 | 26433 / 26520 | | 11672 / 11801 | 15406 / 15395 |
| 12 | 2268 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 17314 / 16687 | 22678 / 22327 | 38814 / 39586 | | 22855 / 23085 | 26485 / 26008 |
| 13 | 2268 | 4016 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 8429 / 8492 | 11595 / 11698 | 26488 / 26341 | | 11522 / 11514 | 14915 / 14754 |
| 14 | 696 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 16522 / 19560 | 22437 / 27109 | 39551 / 44098 | | 22523 / 27228 | 26632 / 30205 |
| 15 | 696 | 10752 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 8433 / 8498 | 11691 / 11789 | 26268 / 26441 | | 11525 / 11634 | 14927 / 14912 |
| 16 | 3220 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 22884 / 19741 | 32132 / 25999 | 49322 / 42480 | | 32436 / 25349 | 35791 / 29121 |
| 17 | 3220 | 1184 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 8614 / 8384 | 11566 / 11527 | 26262 / 26139 | | 11360 / 11430 | 15039 / 14861 |
| 18 | 1712 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 17167 / 23265 | 22404 / 33182 | 39254 / 51141 | | 22311 / 32910 | 26495 / 36751 |
| 19 | 1712 | 7984 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 8508 / 8543 | 11484 / 11462 | 26013 / 26116 | | 11557 / 11542 | 14822 / 14834 |
| 20 | 76 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 23374 / 15934 | 33288 / 22150 | 51158 / 39754 | | 32958 / 22615 | 36725 / 25997 |
| 21 | 76 | 14720 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 8442 / 8433 | 11552 / 11548 | 26211 / 26390 | | 11554 / 11445 | 14755 / 14935 |
| 22 | 2664 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 23023 / 21825 | 33266 / 28972 | 50886 / 46072 | | 33243 / 28827 | 36625 / 32888 |
| 23 | 2664 | 5136 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 8400 / 8426 | 11482 / 11492 | 26145 / 25956 | | 11582 / 11617 | 15390 / 14881 |
| stock | - | - | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 23509 / 23205 | 33407 / 33352 | 51090 / 51202 | 21935 / 21927 | 32882 / 32915 | 36538 / 36649 |

Region base: most common 0x300000000 in 51% of the first case's base runs.

</details>

