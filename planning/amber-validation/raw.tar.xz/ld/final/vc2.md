
## Layout-randomised timings (designed: code and data)

Each case re-timed across designed variants of base and of branch (pbt/ldesign.py, seed 0). Pad j (an unused
function at the top of `src/0.c`) is built once and timed twice: at the stock data placement (colour 0) and at a
designed colour C_j (`AMBER_COLOUR`, a fork-only hook in the variant builds' `src/m.c`: each block of 64 KB or
more moved c*(k+1) mod 16 KB into its slot); pads and colours are one 2-D Kronecker sequence. Base and branch of
a variant run back to back (random order), 7 rounds after a first run of each; the stock (unpadded, unhooked)
builds as one more pair in the first batch (Stock layout; ** when measurable), and variant 0 again in each later
batch (an anchor). Adaptive: 8 variants, then 4 more at a time while the interval is wider than +-1.0%, up to
24.

Change: geometric mean of the per-variant median paired ratios branch/base (per pad first), with a t interval
over the pads (pads - 1 df); Stock data and Designed data: the same over each half alone. Code: the range of the
stock-data variants' medians (base / branch; later batches scaled by their anchor), the slowest against their
median (the worse version), and the case's p-value (labels permuted within a batch's rounds, statistic the
within-batch sum of squares of trimmed means; the smaller of base's and branch's, doubled). Data: how much
slower the stock data placement is than the designed one (stock / designed - 1 per pad: the median over the
pads, base / branch, and the largest either way), and the p-value (sign-flip permutation within rounds).
**code** / **data**: significant after Benjamini-Hochberg across the cases (q = 0.05), p <= 0.01, and over the
threshold (3%, 10% under 5 ms). Spread: the range of all variant medians. Run: the run-to-run region base (ASLR)
at its most common address or not, the largest change it makes at one colour (max-|z| permutation test over the
colours, labels permuted within variants); when p < 0.05 each run is adjusted for it, per colour, for the tests,
and each variant's change is taken within categories (post-stratified). Verdict: **change** when the interval
excludes no change and the change is over the threshold; otherwise placement when the stock change is measurable
or the case is flagged; noise otherwise; data-dependent when the stock-data and designed-data changes differ
(paired t over pads, p < 0.01, over the threshold). Attributed "stock code layout": the stock pair's change is
measurable and its interval misses the stock-data variants' (they differ from it in code only: no pad, no hook,
the same data placement).

Flagged (of 5 cases): code 0, data 3, run 1; change 4, data-dependent 3; stock code layout 0; intervals containing no change: 1.

| Case | Stock layout | Layout-averaged change | 95% interval | K | Stock data | Designed data | Code | Data | Spread | Run | Attributed | Verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| `win.k: s_msum100` | -67.3% (-70.4% to -56.2%) ** | -47.1% | -49.8% to -44.3% | 24 | -65.6% (-69.1% to -61.8%) | -18.7% (-19.1% to -18.3%) | 81.8% / 6.2%, worst +3.9% (p 0.73) | +164.3% / +0.9%, max 174.4% (p 0.0001) **data** | 132.9% / 6.2% | (p 0.17) | data | **change**, data-dependent |
| `win.k: s_mavg100` | -78.2% (-79.3% to -68.4%) ** | -62.0% | -64.2% to -59.6% | 24 | -75.6% (-78.4% to -72.5%) | -40.7% (-41.1% to -40.3%) | 94.3% / 0.9%, worst +2.5% (p 1) | +181.9% / +2.0%, max 190.9% (p 0.0001) **data** | 143.5% / 3.8% | (p 0.16) | data | **change**, data-dependent |
| `win.k: s_mdev100` | -66.7% (-66.9% to -56.7%) ** | -47.9% | -49.4% to -46.3% | 24 | -58.8% (-61.2% to -56.3%) | -34.1% (-34.5% to -33.7%) | 6.8% / 2.0%, worst +4.9% (p 0.78) | +42.3% / -0.6%, max 49.2% (p 0.0001) **data** | 41.3% / 3.2% | +39.1% at colour 0 (p 0.0001) **run**, adjusted | data+run | **change**, data-dependent |
| `win.k: s_mmin100` | -33.2% (-35.2% to -33.1%) ** | -32.5% | -33.0% to -31.9% | 12 | -32.6% (-33.5% to -31.8%) | -32.3% (-33.2% to -31.4%) | 1.3% / 1.3%, worst +0.5% (p 0.98) | -0.3% / -0.3%, max 1.4% (p 0.94) | 1.4% / 1.9% | (p 0.63) | - | **change** |
| `win.k: s_mmin10` | -2.8% (-4.7% to +1.4%) | +0.1% | -0.8% to +1.0% | 16 | +0.3% (-0.7% to +1.2%) | +0.0% (-1.3% to +1.4%) | 3.8% / 1.1%, worst +3.9% (p 0.098) | +0.2% / +1.2%, max 4.9% (p 0.15) | 4.8% / 2.6% | (p 0.22) | - | noise |

<details><summary>Design and variants</summary>

12 pads: 76, 364, 696, 1316, 1712, 1872, 2268, 2664, 2824, 3220, 3508, 3776; largest gap mod 4096 620 B (even: 341); 12 of 16 phases mod 64, 4 of 4 mod 16.
12 designed colours (and 0, the stock placement): 48, 1184, 2832, 4016, 5136, 6800, 7984, 9632, 10752, 12416, 13600, 14720; largest gap mod 16384 1664 B (even: 1260); 4 of 4 phases mod 64.

Shift: the most common move of a function against the pad-0 variant build (mod 4096) and the share of
functions not moved (an order file's pinned region); Loops: small loops straddling a 4 KB boundary.

| Variant | Pad | Colour | Base shift | Branch shift | Base loops | Branch loops | win.k: s_msum100 base / branch | win.k: s_mavg100 base / branch | win.k: s_mdev100 base / branch | win.k: s_mmin100 base / branch | win.k: s_mmin10 base / branch |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | 3508 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 23050 / 7112 | 33466 / 7154 | 51597 / 17359 | 22437 / 14983 | 12581 / 12802 |
| 1 | 3508 | 12416 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 8522 / 6955 | 11504 / 6934 | 26464 / 17458 | 22295 / 15182 | 12550 / 12550 |
| 2 | 1872 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 23525 / 7099 | 33069 / 7121 | 51159 / 17399 | 22188 / 15175 | 12579 / 12746 |
| 3 | 1872 | 2832 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 8589 / 7048 | 11808 / 7068 | 26563 / 17533 | 22394 / 15018 | 12481 / 12634 |
| 4 | 364 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 22874 / 7052 | 33307 / 7135 | 51688 / 17343 | 22342 / 15117 | 12541 / 12733 |
| 5 | 364 | 9632 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 8590 / 6972 | 11713 / 6975 | 26589 / 17429 | 22372 / 15076 | 12629 / 12875 |
| 6 | 2824 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 17612 / 7101 | 23943 / 7132 | 40720 / 17340 | 22474 / 15014 | 12779 / 12667 |
| 7 | 2824 | 48 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 8556 / 7038 | 11794 / 7068 | 26451 / 17353 | 22453 / 15159 | 12753 / 12636 |
| 8 | 1316 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 23024 / 6967 | 33223 / 7000 | 51102 / 17268 | 22181 / 15104 | 12601 / 12714 |
| 9 | 1316 | 6800 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 8777 / 7089 | 11709 / 6905 | 26665 / 17661 | 22371 / 15012 | 12506 / 12480 |
| 10 | 3776 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 13793 / 6945 | 18793 / 6993 | 35141 / 17229 | 22378 / 15098 | 13083 / 12679 |
| 11 | 3776 | 13600 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 8467 / 6903 | 11672 / 6964 | 26887 / 17673 | 22503 / 15305 | 12475 / 12494 |
| 12 | 2268 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 23052 / 7227 | 33147 / 6963 | 50899 / 17534 | | 12391 / 12550 |
| 13 | 2268 | 4016 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 8449 / 6898 | 11484 / 6701 | 26298 / 17114 | | 12622 / 12275 |
| 14 | 696 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 20924 / 6798 | 26793 / 6902 | 43052 / 17193 | | 12635 / 12568 |
| 15 | 696 | 10752 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 8383 / 6805 | 11452 / 6758 | 26392 / 17142 | | 12799 / 12510 |
| 16 | 3220 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 23010 / 6779 | 33029 / 6901 | 50866 / 16997 | | |
| 17 | 3220 | 1184 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 8393 / 6885 | 11412 / 6729 | 26018 / 17630 | | |
| 18 | 1712 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 22933 / 6776 | 33101 / 6895 | 50967 / 17165 | | |
| 19 | 1712 | 7984 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 8358 / 6720 | 11470 / 6931 | 26177 / 17315 | | |
| 20 | 76 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 19159 / 6814 | 26340 / 6904 | 44589 / 17307 | | |
| 21 | 76 | 14720 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 8362 / 6736 | 11405 / 6698 | 26089 / 17157 | | |
| 22 | 2664 | 0 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 16892 / 6790 | 22349 / 6879 | 38852 / 17192 | | |
| 23 | 2664 | 5136 | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 8386 / 6678 | 11720 / 6747 | 26301 / 17271 | | |
| stock | - | - | 0 (0.0% unmoved) | 0 (0.0% unmoved) | 0 | 0 | 23680 / 7337 | 33713 / 7150 | 52267 / 17360 | 22557 / 14975 | 12843 / 12627 |

Region base: most common 0x300000000 in 42% of the first case's base runs.

</details>

