# Layout timings: `main`

Base `main` (7dcf56e61), branch 7dcf56e61.

## Layout-randomised timings (designed: code and data)

Each case re-timed across designed variants of base and of branch (pbt/ldesign.py, seed 0): variant i has
the code pad of pad i//2 (an unused function at the top of `src/0.c`) and the data colour of colour (i+1)//2
(`AMBER_COLOUR`: each block of 64 KB or more moved c*(k+1) mod 16 KB into its slot, a fork-only hook in the
variant builds' `src/m.c`), so each pad is timed under two colours (a data contrast) and each colour under two
pads (a code contrast).
Base and branch of a variant run back to back (random order), 7 rounds after a first run of each;
the stock (unpadded, unhooked) builds as one more pair in the first batch (Stock layout; ** when measurable).
Adaptive: 8 variants, then 4 more at a time while the interval is wider than +-1.0%, up to 24.
Change: geometric mean over variants of the median paired ratio branch/base; 95% interval t-based (variants
sharing a pad summed, the shared-colour covariance added, m-1 df for m pads). Code / Data: the largest
contrast of variant medians (base / branch) and the case's p-value (sign-flip permutation within rounds,
the smaller of base's and branch's, doubled); **code** / **data** when significant after Benjamini-Hochberg
across the cases at q = 0.05 and the contrast is over the threshold (3%, 10% under 5 ms). Spread: range of
variant medians; Worst: the slowest variant against the median (base / branch). Run: the run-to-run region
base (ASLR), at its most common address or not: the change in time it makes, labels permuted within variants;
when p < 0.05 each run is adjusted for it (a covariate) before the change and the code and data tests.
Verdict: **change** when the interval excludes no change and the change is over the threshold; otherwise
placement when the stock change is measurable or the case is flagged; noise otherwise.

Flagged: code 0, data 3, run 3 of 4 cases; change 0.

| Case | Stock layout | Layout-averaged change | 95% interval | K | Code | Data | Spread | Worst | Run | Attributed | Verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|
| `win.k: s_msum100` (series) | +5.5% (-4.8% to +50.3%) | -0.3% | -1.6% to +0.9% | 24 | 23.4% / 20.5% (p 0.59) | 171.9% / 167.1% (p 0.0003) **data** | 177.3% / 169.3% | +175.2% / +165.4% | +4.3% (p 0.006) **run**, adjusted | data+run | placement |
| `win.k: s_mavg100` | +0.7% (-6.3% to +43.3%) | +0.1% | -0.7% to +0.8% | 20 | 25.9% / 24.3% (p 1) | 182.3% / 173.0% (p 0.0001) **data** | 183.5% / 179.8% | +180.6% / +175.4% | +4.8% (p 0.005) **run**, adjusted | data+run | placement |
| `win.k: s_mdev100` | +0.2% (-4.5% to +30.4%) | +0.4% | -0.6% to +1.3% | 16 | 20.1% / 19.1% (p 1) | 90.8% / 88.1% (p 0.0003) **data** | 90.5% / 90.2% | +88.6% / +89.0% | +3.8% (p 0.003) **run**, adjusted | data+run | placement |
| `win.k: s_mmin100` | +0.3% (-2.5% to +1.4%) | +0.1% | -0.6% to +0.7% | 8 | 0.9% / 1.0% (p 1) | 1.2% / 2.1% (p 1) | 1.4% / 2.2% | +1.2% / +1.4% | -0.5% (p 0.69) | - | noise |

<details><summary>Design and variants</summary>

12 pads: 76, 364, 696, 1316, 1712, 1872, 2268, 2664, 2824, 3220, 3508, 3776; largest gap mod 4096 620 B (even: 341); 12 of 16 phases mod 64, 4 of 4 mod 16.
13 colours: 0, 48, 1184, 4016, 5136, 6800, 7984, 9632, 10752, 11952, 12416, 13600, 14720; largest gap mod 16384 2832 B (even: 1260); 4 of 4 phases mod 64.

Shift: the most common move of a function against the hooked unpadded build (mod 4096) and the share of
functions not moved (an order file's pinned region); Loops: small loops straddling a 4 KB boundary.

| Variant | Pad | Colour | Base shift | Branch shift | Base loops | Branch loops | win.k: s_msum100 base / branch | win.k: s_mavg100 base / branch | win.k: s_mdev100 base / branch | win.k: s_mmin100 base / branch |
|---|---|---|---|---|---|---|---|---|---|---|
| 0 | 3508 | 12416 | 3508 (0.3% unmoved) | 3508 (0.3% unmoved) | 75 | 75 | 8203 / 8205 | 11574 / 11436 | 26251 / 26109 | 21851 / 21950 |
| 1 | 3508 | 0 | 3508 (0.3% unmoved) | 3508 (0.3% unmoved) | 75 | 75 | 17223 / 17282 | 23708 / 23845 | 39222 / 40000 | 22120 / 21971 |
| 2 | 1872 | 0 | 1872 (0.3% unmoved) | 1872 (0.3% unmoved) | 78 | 78 | 23061 / 22678 | 33188 / 32992 | 50811 / 51324 | 21922 / 21802 |
| 3 | 1872 | 9632 | 1872 (0.3% unmoved) | 1872 (0.3% unmoved) | 78 | 78 | 8384 / 8213 | 11758 / 11554 | 26277 / 26409 | 21850 / 22275 |
| 4 | 364 | 9632 | 364 (0.3% unmoved) | 364 (0.3% unmoved) | 66 | 66 | 8190 / 8201 | 11588 / 11474 | 26390 / 26221 | 21871 / 22053 |
| 5 | 364 | 48 | 364 (0.3% unmoved) | 364 (0.3% unmoved) | 66 | 66 | 8263 / 8332 | 11486 / 11660 | 26415 / 26229 | 21804 / 21997 |
| 6 | 2824 | 48 | 2824 (0.3% unmoved) | 2824 (0.3% unmoved) | 85 | 85 | 8182 / 8225 | 11461 / 11474 | 26289 / 26207 | 22013 / 21836 |
| 7 | 2824 | 6800 | 2824 (0.3% unmoved) | 2824 (0.3% unmoved) | 85 | 85 | 8162 / 8458 | 11463 / 11752 | 26227 / 26266 | 21840 / 21798 |
| 8 | 1316 | 6800 | 1316 (0.3% unmoved) | 1316 (0.3% unmoved) | 73 | 73 | 8237 / 8181 | 11693 / 11437 | 26422 / 26214 | |
| 9 | 1316 | 13600 | 1316 (0.3% unmoved) | 1316 (0.3% unmoved) | 73 | 73 | 8229 / 8205 | 11674 / 11474 | 26228 / 26285 | |
| 10 | 3776 | 13600 | 3776 (0.3% unmoved) | 3776 (0.3% unmoved) | 72 | 72 | 8209 / 8501 | 11474 / 11668 | 26605 / 26191 | |
| 11 | 3776 | 4016 | 3776 (0.3% unmoved) | 3776 (0.3% unmoved) | 72 | 72 | 8235 / 8207 | 11572 / 11474 | 26359 / 26640 | |
| 12 | 2268 | 4016 | 2268 (0.3% unmoved) | 2268 (0.3% unmoved) | 91 | 91 | 8286 / 8551 | 11491 / 11683 | 26277 / 26392 | |
| 13 | 2268 | 10752 | 2268 (0.3% unmoved) | 2268 (0.3% unmoved) | 91 | 91 | 8190 / 8279 | 11472 / 11435 | 26187 / 26645 | |
| 14 | 696 | 10752 | 696 (0.3% unmoved) | 696 (0.3% unmoved) | 82 | 82 | 8270 / 8447 | 11458 / 11546 | 26296 / 26319 | |
| 15 | 696 | 1184 | 696 (0.3% unmoved) | 696 (0.3% unmoved) | 82 | 82 | 8352 / 8215 | 11750 / 11487 | 26507 / 26226 | |
| 16 | 3220 | 1184 | 3220 (0.3% unmoved) | 3220 (0.3% unmoved) | 69 | 69 | 8334 / 8198 | 11418 / 11417 | | |
| 17 | 3220 | 7984 | 3220 (0.3% unmoved) | 3220 (0.3% unmoved) | 69 | 69 | 8161 / 8207 | 11487 / 11470 | | |
| 18 | 1712 | 7984 | 1712 (0.3% unmoved) | 1712 (0.3% unmoved) | 59 | 59 | 8345 / 8215 | 11512 / 11478 | | |
| 19 | 1712 | 14720 | 1712 (0.3% unmoved) | 1712 (0.3% unmoved) | 59 | 59 | 8290 / 8286 | 11784 / 11516 | | |
| 20 | 76 | 14720 | 76 (0.3% unmoved) | 76 (0.3% unmoved) | 70 | 70 | 8270 / 8225 | | | |
| 21 | 76 | 5136 | 76 (0.3% unmoved) | 76 (0.3% unmoved) | 70 | 70 | 8299 / 8318 | | | |
| 22 | 2664 | 5136 | 2664 (0.3% unmoved) | 2664 (0.3% unmoved) | 84 | 84 | 8175 / 8237 | | | |
| 23 | 2664 | 11952 | 2664 (0.3% unmoved) | 2664 (0.3% unmoved) | 84 | 84 | 8252 / 8283 | | | |
| stock | - | - | 4092 (0.2% unmoved) | 4092 (0.2% unmoved) | 79 | 79 | 22871 / 23393 | 33050 / 33213 | 51362 / 51114 | 22118 / 22026 |

Region base: most common 0x300000000 in 52% of the first case's base runs.

Batches (variants, cases timed): 8 x 4, 12 x 3, 16 x 3, 20 x 2, 24 x 1; variants per case: 8: 1, 16: 1, 20: 1, 24: 1.
Builds and checks 24 s; timings 59 s (401 runs); load 2.80, 2.63, 2.63, 2.77, 2.63, 2.75, 2.64, 2.82, 2.70, 3.12 (start and end of each batch).

</details>

Raw timings: `/private/tmp/claude-501/-Users-dave-work-ngn-k-k/eb2f95d5-4068-4d95-8225-d12e510d750c/scratchpad/ld/lv/raw/20261004-160659.json`.

