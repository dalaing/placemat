# Layout timings: `main`

Base `main` (7dcf56e61), branch 7dcf56e61.

## Layout-randomised timings (designed: code and data)

Each case re-timed across designed variants of base and of branch (pbt/ldesign.py, seed 0): variant i has
the code pad of pad i//2 (an unused function at the top of `src/0.c`) and the data colour of colour (i+1)//2
(`AMBER_COLOUR`: each block of 64 KB or more moved c*(k+1) mod 16 KB into its slot, a fork-only hook in the
variant builds' `src/m.c`), so each pad is timed under two colours (a data contrast) and each colour under two
pads (a code contrast).
Base and branch of a variant run back to back (random order), 7 rounds after a first run of each;
the stock (unpadded, unhooked) builds as one more pair in the first batch (Stock layout; ** when measurable).
Adaptive: 8 variants, then 4 more at a time while the interval is wider than +-1.0%, up to 24.
Change: geometric mean over variants of the median paired ratio branch/base; 95% interval t-based (variants
sharing a pad summed, the shared-colour covariance added, m-1 df for m pads). Code / Data: the largest
contrast of variant medians (base / branch) and the case's p-value (sign-flip permutation within rounds,
the smaller of base's and branch's, doubled); **code** / **data** when significant after Benjamini-Hochberg
across the cases at q = 0.05 and the contrast is over the threshold (3%, 10% under 5 ms). Spread: range of
variant medians; Worst: the slowest variant against the median (base / branch). Run: the run-to-run region
base (ASLR), at its most common address or not: the largest change in time it makes at one colour (it can
matter at one data placement only), labels permuted within variants, the largest |z| over colours as the
statistic; when p < 0.05 each run is adjusted for it, per colour (a covariate), before everything else.
Verdict: **change** when the interval excludes no change and the change is over the threshold; otherwise
placement when the stock change is measurable or the case is flagged; noise otherwise.

Flagged: code 0, data 3, run 3 of 4 cases; change 0.

| Case | Stock layout | Layout-averaged change | 95% interval | K | Code | Data | Spread | Worst | Run | Attributed | Verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|
| `win.k: s_msum100` (series) | -27.8% (-39.2% to +0.3%) | -4.3% | -14.1% to +6.7% | 12 | 3.6% / 5.9% (p 0.3) | 88.6% / 36.7% (p 0.0008) **data** | 91.1% / 45.4% | +90.3% / +42.5% | +105.2% at colour 0 (p 0.022) **run**, adjusted | data+run | placement |
| `win.k: s_mavg100` | -30.1% (-36.9% to +0.8%) | -1.9% | -6.4% to +3.0% | 24 | 1.7% / 3.3% (p 0.15) | 84.6% / 40.6% (p 0.0003) **data** | 86.8% / 40.7% | +84.5% / +38.7% | +107.5% at colour 0 (p 0.022) **run**, adjusted | data+run | placement |
| `win.k: s_mdev100` | -24.2% (-25.8% to +2.4%) | -1.4% | -4.5% to +1.8% | 24 | 2.0% / 2.2% (p 0.084) | 45.5% / 18.8% (p 0.0073) **data** | 49.0% / 22.9% | +47.6% / +21.3% | +62.1% at colour 0 (p 0.0067) **run**, adjusted | data+run | placement |
| `win.k: s_mmin100` | +0.9% (-0.1% to +2.2%) | +0.6% | -0.1% to +1.3% | 8 | 1.2% / 2.8% (p 0.2) | 1.3% / 2.7% (p 0.56) | 1.5% / 2.8% | +0.9% / +2.5% | +2.1% at colour 6800 (p 0.44) | - | noise |

<details><summary>Design and variants</summary>

12 pads: 76, 364, 696, 1316, 1712, 1872, 2268, 2664, 2824, 3220, 3508, 3776; largest gap mod 4096 620 B (even: 341); 12 of 16 phases mod 64, 4 of 4 mod 16.
13 colours: 0, 48, 1184, 4016, 5136, 6800, 7984, 9632, 10752, 11952, 12416, 13600, 14720; largest gap mod 16384 2832 B (even: 1260); 4 of 4 phases mod 64.

Shift: the most common move of a function against the hooked unpadded build (mod 4096) and the share of
functions not moved (an order file's pinned region); Loops: small loops straddling a 4 KB boundary.

| Variant | Pad | Colour | Base shift | Branch shift | Base loops | Branch loops | win.k: s_msum100 base / branch | win.k: s_mavg100 base / branch | win.k: s_mdev100 base / branch | win.k: s_mmin100 base / branch |
|---|---|---|---|---|---|---|---|---|---|---|
| 0 | 3508 | 12416 | 3508 (0.3% unmoved) | 3508 (0.3% unmoved) | 75 | 75 | 8212 / 8433 | 11516 / 11588 | 26348 / 26491 | 21927 / 21876 |
| 1 | 3508 | 0 | 3508 (0.3% unmoved) | 3508 (0.3% unmoved) | 75 | 75 | 22663 / 15954 | 32934 / 22997 | 51184 / 39176 | 22097 / 22488 |
| 2 | 1872 | 0 | 1872 (0.3% unmoved) | 1872 (0.3% unmoved) | 78 | 78 | 22949 / 23042 | 33281 / 33545 | 51909 / 51229 | 21912 / 21878 |
| 3 | 1872 | 9632 | 1872 (0.3% unmoved) | 1872 (0.3% unmoved) | 78 | 78 | 8343 / 8213 | 11566 / 11493 | 26258 / 26603 | 21761 / 22227 |
| 4 | 364 | 9632 | 364 (0.3% unmoved) | 364 (0.3% unmoved) | 66 | 66 | 8208 / 8214 | 11552 / 11468 | 26248 / 26264 | 21883 / 21920 |
| 5 | 364 | 48 | 364 (0.3% unmoved) | 364 (0.3% unmoved) | 66 | 66 | 8251 / 8198 | 11438 / 11796 | 26323 / 26541 | 21830 / 21966 |
| 6 | 2824 | 48 | 2824 (0.3% unmoved) | 2824 (0.3% unmoved) | 85 | 85 | 8300 / 8346 | 11472 / 11420 | 26490 / 26416 | 22089 / 22330 |
| 7 | 2824 | 6800 | 2824 (0.3% unmoved) | 2824 (0.3% unmoved) | 85 | 85 | 8230 / 8311 | 11526 / 11581 | 26393 / 26305 | 21805 / 21910 |
| 8 | 1316 | 6800 | 1316 (0.3% unmoved) | 1316 (0.3% unmoved) | 73 | 73 | 8298 / 8370 | 11526 / 11715 | 26201 / 26575 | |
| 9 | 1316 | 13600 | 1316 (0.3% unmoved) | 1316 (0.3% unmoved) | 73 | 73 | 8160 / 8163 | 11486 / 11583 | 26225 / 26228 | |
| 10 | 3776 | 13600 | 3776 (0.3% unmoved) | 3776 (0.3% unmoved) | 72 | 72 | 8227 / 8258 | 11549 / 11480 | 26588 / 26468 | |
| 11 | 3776 | 4016 | 3776 (0.3% unmoved) | 3776 (0.3% unmoved) | 72 | 72 | 8220 / 8381 | 11495 / 11569 | 26286 / 26657 | |
| 12 | 2268 | 4016 | 2268 (0.3% unmoved) | 2268 (0.3% unmoved) | 91 | 91 | | 11669 / 11668 | 26319 / 26142 | |
| 13 | 2268 | 10752 | 2268 (0.3% unmoved) | 2268 (0.3% unmoved) | 91 | 91 | | 11628 / 11720 | 25936 / 26347 | |
| 14 | 696 | 10752 | 696 (0.3% unmoved) | 696 (0.3% unmoved) | 82 | 82 | | 11663 / 11887 | 26110 / 26384 | |
| 15 | 696 | 1184 | 696 (0.3% unmoved) | 696 (0.3% unmoved) | 82 | 82 | | 12018 / 12132 | 26079 / 26067 | |
| 16 | 3220 | 1184 | 3220 (0.3% unmoved) | 3220 (0.3% unmoved) | 69 | 69 | | 11960 / 12046 | 26554 / 26486 | |
| 17 | 3220 | 7984 | 3220 (0.3% unmoved) | 3220 (0.3% unmoved) | 69 | 69 | | 11843 / 11733 | 26230 / 26225 | |
| 18 | 1712 | 7984 | 1712 (0.3% unmoved) | 1712 (0.3% unmoved) | 59 | 59 | | 11645 / 11799 | 26344 / 26034 | |
| 19 | 1712 | 14720 | 1712 (0.3% unmoved) | 1712 (0.3% unmoved) | 59 | 59 | | 11600 / 11641 | 26001 / 25993 | |
| 20 | 76 | 14720 | 76 (0.3% unmoved) | 76 (0.3% unmoved) | 70 | 70 | | 11692 / 11699 | 26237 / 26107 | |
| 21 | 76 | 5136 | 76 (0.3% unmoved) | 76 (0.3% unmoved) | 70 | 70 | | 11649 / 11593 | 26008 / 25987 | |
| 22 | 2664 | 5136 | 2664 (0.3% unmoved) | 2664 (0.3% unmoved) | 84 | 84 | | 11752 / 11658 | 26018 / 26503 | |
| 23 | 2664 | 11952 | 2664 (0.3% unmoved) | 2664 (0.3% unmoved) | 84 | 84 | | 11640 / 11691 | 25998 / 26228 | |
| stock | - | - | 4092 (0.2% unmoved) | 4092 (0.2% unmoved) | 79 | 79 | 23800 / 16872 | 33153 / 23173 | 51149 / 39519 | 22080 / 22149 |

Region base: most common 0x300000000 in 46% of the first case's base runs.

Batches (variants, cases timed): 8 x 4, 12 x 3, 16 x 2, 20 x 2, 24 x 2; variants per case: 8: 1, 12: 1, 24: 2.
Builds and checks 0 s; timings 56 s (401 runs); load 2.22, 2.74, 2.74, 2.71, 2.71, 2.57, 2.57, 2.78, 2.78, 2.75 (start and end of each batch).

</details>

Raw timings: `/private/tmp/claude-501/-Users-dave-work-ngn-k-k/eb2f95d5-4068-4d95-8225-d12e510d750c/scratchpad/ld/lv/raw/20261004-160923.json`.

