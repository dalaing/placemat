# Layout timings: `main`

Base `main` (7dcf56e61), branch 7dcf56e61.

## Layout-randomised timings (designed: code and data)

Each case re-timed across designed variants of base and of branch (pbt/ldesign.py, seed 0). Pad j (an
unused function at the top of `src/0.c`) is built once and timed twice: at the stock data placement (colour 0)
and at a designed colour C_j (`AMBER_COLOUR`, a fork-only hook in the variant builds' `src/m.c`: each block of
64 KB or more moved c*(k+1) mod 16 KB into its slot). Pads and colours are one 2-D Kronecker sequence.
Base and branch of a variant run back to back (random order), 7 rounds after a first run of each;
the stock (unpadded, unhooked) builds as one more pair in the first batch (Stock layout; ** when measurable).
Adaptive: 8 variants, then 4 more at a time while the interval is wider than +-1.0%, up to 24.
Change: geometric mean of the per-variant median paired ratios branch/base (per pad first), with a t interval
over the pads (pads - 1 df); Stock data and Designed data: the same over each half alone.
Code: the largest range of the stock-data variants' medians within a batch (variants timed together; base /
branch) and the case's p-value (variant labels permuted within a batch's rounds, statistic the within-batch
sum of squares; the smaller of base's and branch's, doubled). Data: how much slower the stock data placement is than the designed one (stock / designed - 1 per pad:
median over the pads (base / branch), and the largest either way), and the p-value (sign-flip permutation within rounds). **code** / **data**: significant after Benjamini-Hochberg across the cases (q = 0.05) and over the
threshold (3%, 10% under 5 ms). Spread: the largest range of variant medians within a batch. Run: the run-to-run region base (ASLR) at
its most common address or not, the largest change it makes at one colour (max-|z| permutation test over the
colours, labels permuted within variants); when p < 0.05 each run is adjusted for it, per colour, for the tests, and each variant's change is
taken within categories (post-stratified).
Verdict: **change** when the interval excludes no change and the change is over the threshold; otherwise
placement when the stock change is measurable or the case is flagged; noise otherwise. Attributed "stock code
layout": the stock pair's change is measurable and its interval misses the stock-data variants' (they differ
from it in code only: no pad, no hook, the same data placement); data-dependent when the stock-data and designed-data changes differ (paired t over pads, p < 0.01, over the threshold).

Flagged (of 6 cases): code 0, data 5, run 5; change 0, data-dependent 0; stock code layout 0; intervals containing no change: 6.

| Case | Stock layout | Layout-averaged change | 95% interval | K | Stock data | Designed data | Code | Data | Spread | Run | Attributed | Verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| `win.k: s_msum100` | +1.9% (-45.1% to +53.5%) | +0.1% | -3.8% to +4.2% | 24 | +0.8% (-6.9% to +9.2%) | -0.6% (-1.4% to +0.2%) | 53.0% / 15.4% (p 0.034) | +90.3% / +92.4%, max 99.4% (p 0.0001) **data** | 106.2% / 75.7% | +44.6% at colour 0 (p 0.0001) **run**, adjusted | data+run | placement |
| `win.k: s_mavg100` | +0.7% (-46.9% to +52.2%) | -0.1% | -4.1% to +4.2% | 24 | +0.3% (-7.3% to +8.6%) | -0.4% (-1.2% to +0.4%) | 57.5% / 8.6% (p 0.033) | +91.9% / +93.6%, max 97.4% (p 0.0001) **data** | 110.6% / 70.9% | +50.9% at colour 0 (p 0.0001) **run**, adjusted | data+run | placement |
| `win.k: s_mdev100` | +0.7% (-30.7% to +22.2%) | -0.1% | -2.7% to +2.4% | 24 | -0.2% (-5.2% to +5.1%) | -0.1% (-0.7% to +0.5%) | 34.7% / 6.8% (p 0.022) | +47.8% / +48.2%, max 51.0% (p 0.0001) **data** | 69.2% / 44.7% | +32.4% at colour 0 (p 0.0001) **run**, adjusted | data+run | placement |
| `win.k: s_mmin100` | -0.9% (-1.7% to +1.0%) | +0.1% | -0.3% to +0.5% | 8 | +0.2% (-1.2% to +1.7%) | -0.0% (-0.7% to +0.6%) | 1.3% / 3.1% (p 0.62) | +0.4% / -0.3%, max 2.6% (p 0.33) | 1.4% / 3.1% | (p 0.34) | - | noise |
| `win.k: s_mavg10` | +0.7% (-50.8% to +49.8%) | -0.1% | -3.7% to +3.7% | 24 | -0.2% (-7.4% to +7.7%) | -0.0% (-0.8% to +0.7%) | 59.7% / 5.4% (p 0.043) | +91.4% / +91.1%, max 98.7% (p 0.0001) **data** | 113.0% / 67.4% | +51.2% at colour 0 (p 0.0001) **run**, adjusted | data+run | placement |
| `win.k: s_mavg1000` | -0.0% (-43.9% to +39.9%) | +0.7% | -2.7% to +4.2% | 24 | +0.7% (-5.7% to +7.5%) | +0.7% (-0.5% to +1.9%) | 49.3% / 7.8% (p 0.027) | +72.6% / +72.2%, max 76.6% (p 0.0001) **data** | 95.2% / 60.1% | +43.4% at colour 0 (p 0.0001) **run**, adjusted | data+run | placement |

<details><summary>Design and variants</summary>

12 pads: 76, 364, 696, 1316, 1712, 1872, 2268, 2664, 2824, 3220, 3508, 3776; largest gap mod 4096 620 B (even: 341); 12 of 16 phases mod 64, 4 of 4 mod 16.
12 designed colours (and 0, the stock placement): 48, 1184, 2832, 4016, 5136, 6800, 7984, 9632, 10752, 12416, 13600, 14720; largest gap mod 16384 1664 B (even: 1260); 4 of 4 phases mod 64.

Shift: the most common move of a function against the pad-0 variant build (mod 4096) and the share of
functions not moved (an order file's pinned region); Loops: small loops straddling a 4 KB boundary.

| Variant | Pad | Colour | Base shift | Branch shift | Base loops | Branch loops | win.k: s_msum100 base / branch | win.k: s_mavg100 base / branch | win.k: s_mdev100 base / branch | win.k: s_mmin100 base / branch | win.k: s_mavg10 base / branch | win.k: s_mavg1000 base / branch |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | 3508 | 0 | 3508 (0.3% unmoved) | 3508 (0.3% unmoved) | 75 | 75 | 23116 / 22484 | 33307 / 32099 | 51871 / 49846 | 22044 / 21962 | 32879 / 30862 | 36557 / 36119 |
| 1 | 3508 | 12416 | 3508 (0.3% unmoved) | 3508 (0.3% unmoved) | 75 | 75 | 8283 / 8526 | 11429 / 11426 | 26329 / 26265 | 21995 / 22087 | 11248 / 11360 | 14701 / 14767 |
| 2 | 1872 | 0 | 1872 (0.3% unmoved) | 1872 (0.3% unmoved) | 78 | 78 | 22944 / 22946 | 33298 / 33252 | 50958 / 51077 | 22014 / 22517 | 33263 / 32944 | 36220 / 36429 |
| 3 | 1872 | 2832 | 1872 (0.3% unmoved) | 1872 (0.3% unmoved) | 78 | 78 | 8452 / 8234 | 11426 / 11441 | 26275 / 26124 | 22075 / 21956 | 11219 / 11190 | 14749 / 14723 |
| 4 | 364 | 0 | 364 (0.3% unmoved) | 364 (0.3% unmoved) | 66 | 66 | 23086 / 23096 | 33169 / 33136 | 51578 / 50945 | 22148 / 21947 | 32591 / 32669 | 36325 / 36501 |
| 5 | 364 | 9632 | 364 (0.3% unmoved) | 364 (0.3% unmoved) | 66 | 66 | 8339 / 8351 | 11636 / 11425 | 26105 / 25932 | 22010 / 21948 | 11192 / 11192 | 14634 / 14913 |
| 6 | 2824 | 0 | 2824 (0.3% unmoved) | 2824 (0.3% unmoved) | 85 | 85 | 18960 / 22846 | 26031 / 33142 | 43400 / 50958 | 22310 / 21846 | 26406 / 32693 | 28812 / 36083 |
| 7 | 2824 | 48 | 2824 (0.3% unmoved) | 2824 (0.3% unmoved) | 85 | 85 | 8581 / 8301 | 11746 / 11444 | 26271 / 26098 | 22170 / 22140 | 11238 / 11223 | 14738 / 14864 |
| 8 | 1316 | 0 | 1316 (0.3% unmoved) | 1316 (0.3% unmoved) | 73 | 73 | 22860 / 16219 | 33032 / 22243 | 50831 / 38577 | | 32647 / 21980 | 36568 / 25822 |
| 9 | 1316 | 6800 | 1316 (0.3% unmoved) | 1316 (0.3% unmoved) | 73 | 73 | 8499 / 8416 | 11640 / 11472 | 26125 / 26199 | | 11271 / 11561 | 14688 / 15072 |
| 10 | 3776 | 0 | 3776 (0.3% unmoved) | 3776 (0.3% unmoved) | 72 | 72 | 16381 / 23762 | 24069 / 33344 | 38457 / 50836 | | 21925 / 32763 | 25660 / 36726 |
| 11 | 3776 | 13600 | 3776 (0.3% unmoved) | 3776 (0.3% unmoved) | 72 | 72 | 8320 / 8316 | 11437 / 11576 | 26008 / 25856 | | 11419 / 11460 | 14720 / 14658 |
| 12 | 2268 | 0 | 2268 (0.3% unmoved) | 2268 (0.3% unmoved) | 91 | 91 | 22794 / 23657 | 33132 / 33273 | 51090 / 51074 | | 32680 / 33276 | 36578 / 36913 |
| 13 | 2268 | 4016 | 2268 (0.3% unmoved) | 2268 (0.3% unmoved) | 91 | 91 | 8306 / 8299 | 11714 / 11374 | 26748 / 26218 | | 11494 / 11546 | 14697 / 15118 |
| 14 | 696 | 0 | 696 (0.3% unmoved) | 696 (0.3% unmoved) | 82 | 82 | 22898 / 20075 | 33164 / 27627 | 50952 / 44215 | | 33283 / 26696 | 36280 / 30034 |
| 15 | 696 | 10752 | 696 (0.3% unmoved) | 696 (0.3% unmoved) | 82 | 82 | 8330 / 8273 | 11410 / 11551 | 26247 / 26537 | | 11648 / 11503 | 15123 / 15222 |
| 16 | 3220 | 0 | 3220 (0.3% unmoved) | 3220 (0.3% unmoved) | 69 | 69 | 23378 / 23046 | 33027 / 33337 | 50847 / 50720 | | 32950 / 32768 | 36793 / 36314 |
| 17 | 3220 | 1184 | 3220 (0.3% unmoved) | 3220 (0.3% unmoved) | 69 | 69 | 8345 / 8298 | 11405 / 11466 | 26232 / 26141 | | 11516 / 11535 | 14701 / 15226 |
| 18 | 1712 | 0 | 1712 (0.3% unmoved) | 1712 (0.3% unmoved) | 59 | 59 | 15877 / 22897 | 22268 / 32990 | 39796 / 50758 | | 22683 / 32611 | 25682 / 36405 |
| 19 | 1712 | 7984 | 1712 (0.3% unmoved) | 1712 (0.3% unmoved) | 59 | 59 | 8493 / 8338 | 11750 / 11490 | 26276 / 26787 | | 11590 / 11535 | 14701 / 14845 |
| 20 | 76 | 0 | 76 (0.3% unmoved) | 76 (0.3% unmoved) | 70 | 70 | 21725 / 23154 | 29992 / 33120 | 48118 / 51366 | | 29328 / 32620 | 32498 / 36534 |
| 21 | 76 | 14720 | 76 (0.3% unmoved) | 76 (0.3% unmoved) | 70 | 70 | 8327 / 8345 | 11400 / 11480 | 26175 / 26646 | | 11649 / 11452 | 15163 / 14669 |
| 22 | 2664 | 0 | 2664 (0.3% unmoved) | 2664 (0.3% unmoved) | 84 | 84 | 22896 / 16449 | 33156 / 22837 | 51244 / 39194 | | 33543 / 23044 | 36507 / 26315 |
| 23 | 2664 | 5136 | 2664 (0.3% unmoved) | 2664 (0.3% unmoved) | 84 | 84 | 8359 / 8599 | 11417 / 11535 | 26201 / 25888 | | 11601 / 11452 | 14692 / 14810 |
| stock | - | - | 4092 (0.2% unmoved) | 4092 (0.2% unmoved) | 79 | 79 | 16204 / 19027 | 22124 / 26639 | 38737 / 43835 | 22345 / 21957 | 22681 / 25860 | 26110 / 29652 |

Region base: most common 0x300000000 in 50% of the first case's base runs.

Batches (variants, cases timed): 8 x 6, 12 x 5, 16 x 5, 20 x 5, 24 x 5; variants per case: 8: 1, 24: 5.
Builds and checks 0 s; timings 91 s (465 runs); load 2.74, 2.23, 2.23, 2.41, 2.41, 2.39, 2.39, 2.54, 2.54, 2.50 (start and end of each batch).

</details>

Raw timings: `/private/tmp/claude-501/-Users-dave-work-ngn-k-k/eb2f95d5-4068-4d95-8225-d12e510d750c/scratchpad/ld/lv/raw/20261004-170704.json`.

