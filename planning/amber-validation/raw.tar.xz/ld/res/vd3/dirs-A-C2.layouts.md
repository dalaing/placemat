# Layout timings: `/private/tmp/claude-501/-Users-dave-work-ngn-k-k/eb2f95d5-4068-4d95-8225-d12e510d750c/scratchpad/of/C2` against `/private/tmp/claude-501/-Users-dave-work-ngn-k-k/eb2f95d5-4068-4d95-8225-d12e510d750c/scratchpad/of/A`

## Layout-randomised timings (designed: code and data)

Each case re-timed across designed variants of base and of branch (pbt/ldesign.py, seed 0).
Variant i has pad i (an unused function at the top of `src/0.c`) and no data hook (--no-data).
Base and branch of a variant run back to back (random order), 7 rounds after a first run of each;
the stock (unpadded, unhooked) builds as one more pair in the first batch (Stock layout; ** when measurable).
Adaptive: 8 variants, then 4 more at a time while the interval is wider than +-1.0%, up to 8.
Change: geometric mean of the per-variant median paired ratios branch/base (per pad first), with a t interval
over the pads (pads - 1 df).
Code: the largest range of the stock-data variants' medians within a batch (variants timed together; base /
branch), the slowest against their median (worst of base and branch), and the case's p-value (labels permuted within a batch's rounds, statistic the within-batch
sum of squares; the smaller of base's and branch's, doubled).
**code** / **data**: significant after Benjamini-Hochberg across the cases (q = 0.05) and over the
threshold (3%, 10% under 5 ms). Spread: the largest range of variant medians within a batch. Run: the run-to-run region base (ASLR) at
its most common address or not, the largest change it makes at one colour (max-|z| permutation test over the
colours, labels permuted within variants); when p < 0.05 each run is adjusted for it, per colour, for the tests, and each variant's change is
taken within categories (post-stratified).
Verdict: **change** when the interval excludes no change and the change is over the threshold; otherwise
placement when the stock change is measurable or the case is flagged; noise otherwise. Attributed "stock code
layout": the stock pair's change is measurable and its interval misses the stock-data variants' (they differ
from it in code only: no pad, no hook, the same data placement).

Flagged (of 8 cases): code 5, data 0, run 0; change 0; stock code layout 0; intervals containing no change: 8.

| Case | Stock layout | Layout-averaged change | 95% interval | K | Code | Spread | Run | Attributed | Verdict |
|---|---|---|---|---|---|---|---|---|---|
| `microbench: setdictbig` (series) | -1.6% (-4.3% to -0.1%) | -8.4% | -25.5% to +12.5% | 8 | 98.1% / 3.9%, worst +97.6% (p 0.0001) **code** | 98.1% / 3.9% | (p 1) | code | placement |
| `microbench: setdictbigall` (series) | +0.8% (-0.1% to +4.5%) | -8.4% | -25.7% to +12.9% | 8 | 101.8% / 2.4%, worst +101.2% (p 0.0001) **code** | 101.8% / 2.4% | (p 1) | code | placement |
| `microbench: setdictbigname` (series) | +0.5% (-0.9% to +3.3%) | -8.2% | -25.0% to +12.4% | 8 | 98.8% / 1.2%, worst +98.1% (p 0.0002) **code** | 98.8% / 1.2% | (p 1) | code | placement |
| `microbench: chargrade` (series) | +1.5% (-5.1% to +2.4%) | -3.4% | -11.2% to +5.1% | 8 | 33.3% / 2.0%, worst +32.0% (p 0.0002) **code** | 33.3% / 2.0% | (p 1) | code | placement |
| `microbench: takekeys10x10` (series) | -0.9% (-3.4% to +0.3%) | -1.8% | -6.1% to +2.7% | 8 | 15.9% / 2.0%, worst +14.9% (p 0.0002) **code** | 15.9% / 2.0% | (p 1) | code | placement |
| `microbench: grade` | +1.6% (-3.1% to +3.0%) | -0.8% | -2.0% to +0.4% | 8 | 4.1% / 2.9%, worst +2.3% (p 1) | 4.1% / 2.9% | (p 1) | - | noise |
| `microbench: fsum` (series) | -2.4% (-4.0% to +1.9%) | -0.3% | -1.0% to +0.4% | 8 | 3.1% / 2.6%, worst +2.1% (p 0.65) | 3.1% / 2.6% | (p 1) | - | noise |
| `fnd.k: sc_member` | +0.8% (-0.6% to +1.8%) | -0.5% | -1.2% to +0.2% | 8 | 3.4% / 2.4%, worst +3.1% (p 0.44) | 3.4% / 2.4% | (p 1) | - | noise |

<details><summary>Design and variants</summary>

8 pads: 600, 1150, 1200, 1256, 1316, 3260, 3304, 3400; largest gap mod 4096 1944 B (even: 512); 7 of 16 phases mod 64, 5 of 4 mod 16.

Shift: the most common move of a function against the pad-0 variant build (mod 4096) and the share of
functions not moved (an order file's pinned region); Loops: small loops straddling a 4 KB boundary.

| Variant | Pad | Colour | Base shift | Branch shift | Base loops | Branch loops | microbench: setdictbig base / branch | microbench: setdictbigall base / branch | microbench: setdictbigname base / branch | microbench: chargrade base / branch | microbench: takekeys10x10 base / branch | microbench: grade base / branch | microbench: fsum base / branch | fnd.k: sc_member base / branch |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | 1150 | 0 | 1152 (0.3% unmoved) | 1152 (17.5% unmoved) | 68 | 58 | 5994 / 5961 | 6071 / 6041 | 5974 / 6009 | 34209 / 34294 | 44360 / 43733 | 36433 / 35482 | 23226 / 22831 | 23491 / 23185 |
| 1 | 1200 | 0 | 1200 (0.3% unmoved) | 1200 (17.5% unmoved) | 77 | 60 | 6026 / 5998 | 6016 / 6090 | 6017 / 5980 | 34363 / 34178 | 44564 / 44246 | 36322 / 35645 | 23167 / 22784 | 23100 / 23329 |
| 2 | 1256 | 0 | 1256 (0.3% unmoved) | 1248 (17.5% unmoved) | 87 | 65 | 11880 / 5951 | 12167 / 5981 | 11918 / 6019 | 34209 / 34678 | 50936 / 44180 | 35630 / 35493 | 22794 / 22856 | 23137 / 23085 |
| 3 | 1316 | 0 | 1316 (0.3% unmoved) | 1312 (17.5% unmoved) | 91 | 84 | 5983 / 6078 | 6008 / 5987 | 6014 / 5996 | 34785 / 34158 | 44265 / 44612 | 36127 / 36300 | 22799 / 23380 | 23096 / 23103 |
| 4 | 3260 | 0 | 3260 (0.3% unmoved) | 3248 (17.5% unmoved) | 62 | 56 | 6028 / 5942 | 6026 / 5976 | 6028 / 5988 | 34405 / 34189 | 44271 / 44180 | 35546 / 36126 | 23501 / 23094 | 23078 / 23494 |
| 5 | 3304 | 0 | 3304 (0.3% unmoved) | 3296 (17.5% unmoved) | 69 | 51 | 5996 / 6176 | 6240 / 6121 | 6115 / 6054 | 45372 / 34056 | 43899 / 44616 | 35383 / 36513 | 22860 / 22929 | 23861 / 23449 |
| 6 | 3400 | 0 | 3400 (0.3% unmoved) | 3392 (17.5% unmoved) | 68 | 42 | 6120 / 6026 | 6010 / 6027 | 5974 / 6008 | 33919 / 34567 | 44404 / 44375 | 36853 / 36384 | 23160 / 23093 | 23468 / 23346 |
| 7 | 600 | 0 | 600 (0.3% unmoved) | 592 (17.5% unmoved) | 83 | 63 | 5986 / 5966 | 6101 / 6046 | 5993 / 5981 | 34488 / 34728 | 44025 / 44295 | 35946 / 36010 | 22844 / 22959 | 23155 / 23634 |
| stock | - | - | 4092 (0.1% unmoved) | 4080 (17.4% unmoved) | 79 | 57 | 6050 / 5974 | 6042 / 6273 | 5982 / 5985 | 34458 / 34055 | 45027 / 44187 | 37015 / 36510 | 23311 / 22952 | 23288 / 23628 |

Batches (variants, cases timed): 8 x 8; variants per case: 8: 8.
Builds and checks 0 s; timings 166 s (290 runs); load 2.99, 2.54 (start and end of each batch).

</details>

Raw timings: `/private/tmp/claude-501/-Users-dave-work-ngn-k-k/eb2f95d5-4068-4d95-8225-d12e510d750c/scratchpad/ld/lv/raw/20261004-175416.json`.

