# Layout timings: `main`

Base `main` (7dcf56e61), branch 7dcf56e61.

## Layout-randomised timings (designed: code and data)

Each case re-timed across designed variants of base and of branch (pbt/ldesign.py, seed 0). Pad j (an
unused function at the top of `src/0.c`) is built once and timed twice: at the stock data placement (colour 0)
and at a designed colour C_j (`AMBER_COLOUR`, a fork-only hook in the variant builds' `src/m.c`: each block of
64 KB or more moved c*(k+1) mod 16 KB into its slot). Pads and colours are one 2-D Kronecker sequence.
Base and branch of a variant run back to back (random order), 7 rounds after a first run of each;
the stock (unpadded, unhooked) builds as one more pair in the first batch (Stock layout; ** when measurable).
Adaptive: 8 variants, then 4 more at a time while the interval is wider than +-1.0%, up to 24.
Change: geometric mean of the per-variant median paired ratios branch/base (per pad first), with a t interval
over the pads (pads - 1 df); Stock data and Designed data: the same over each half alone.
Code: the range of the stock-data variants' medians (base / branch) and the case's p-value (variant labels
permuted within rounds, statistic their variance; the smaller of base's and branch's, doubled). Data: the median and largest change from the stock placement to the designed one, per pad, and the
p-value (sign-flip permutation within rounds). **code** / **data**: significant after Benjamini-Hochberg across the cases (q = 0.05) and over the
threshold (3%, 10% under 5 ms). Spread: range of all variant medians. Run: the run-to-run region base (ASLR) at
its most common address or not, the largest change it makes at one colour (max-|z| permutation test over the
colours, labels permuted within variants); when p < 0.05 each run is adjusted for it, per colour, before all else.
Verdict: **change** when the interval excludes no change and the change is over the threshold; otherwise
placement when the stock change is measurable or the case is flagged; noise otherwise; data-dependent when the stock-data and designed-data changes differ (paired t over pads, p < 0.01, over the threshold).

Flagged (of 4 cases): code 0, data 3, run 3; change 3, data-dependent 0; intervals containing no change: 1.

| Case | Stock layout | Layout-averaged change | 95% interval | K | Stock data | Designed data | Code | Data | Spread | Run | Attributed | Verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| `win.k: s_msum100` | -0.3% (-25.2% to +71.5%) | -4.7% | -8.0% to -1.3% | 24 | -8.3% (-15.1% to -1.1%) | -0.9% (-2.1% to +0.3%) | 2.8% / 35.9% (p 0.047) | +86.9% / +81.0%, max 94.4% (p 0.0001) **data** | 63.5% / 82.1% | +52.5% at colour 0 (p 0.0001) **run**, adjusted | data+run | **change** |
| `win.k: s_mavg100` | -1.7% (-29.8% to +78.7%) | -5.2% | -9.1% to -1.0% | 24 | -8.9% (-16.5% to -0.7%) | -1.2% (-2.3% to -0.1%) | 2.4% / 40.0% (p 0.037) | +90.8% / +81.3%, max 95.4% (p 0.0001) **data** | 65.2% / 84.9% | +60.3% at colour 0 (p 0.0001) **run**, adjusted | data+run | **change** |
| `win.k: s_mdev100` | -1.3% (-24.3% to +45.6%) | -3.3% | -5.8% to -0.7% | 24 | -5.9% (-10.8% to -0.6%) | -0.6% (-1.2% to -0.0%) | 3.0% / 26.7% (p 0.039) | +48.1% / +42.6%, max 52.9% (p 0.0001) **data** | 42.2% / 47.1% | +37.8% at colour 0 (p 0.0001) **run**, adjusted | data+run | **change** |
| `win.k: s_mmin100` | +0.0% (-0.2% to +1.9%) | +0.6% | -0.3% to +1.6% | 8 | +0.9% (-1.4% to +3.2%) | +0.4% (-0.6% to +1.3%) | 1.3% / 1.9% (p 0.64) | -0.2% / +0.7%, max 2.5% (p 0.78) | 1.3% / 2.5% | +1.9% at colour 48 (p 0.68) | - | noise |

<details><summary>Design and variants</summary>

12 pads: 76, 364, 696, 1316, 1712, 1872, 2268, 2664, 2824, 3220, 3508, 3776; largest gap mod 4096 620 B (even: 341); 12 of 16 phases mod 64, 4 of 4 mod 16.
12 designed colours (and 0, the stock placement): 48, 1184, 2832, 4016, 5136, 6800, 7984, 9632, 10752, 12416, 13600, 14720; largest gap mod 16384 1664 B (even: 1260); 4 of 4 phases mod 64.

Shift: the most common move of a function against the hooked unpadded build (mod 4096) and the share of
functions not moved (an order file's pinned region); Loops: small loops straddling a 4 KB boundary.

| Variant | Pad | Colour | Base shift | Branch shift | Base loops | Branch loops | win.k: s_msum100 base / branch | win.k: s_mavg100 base / branch | win.k: s_mdev100 base / branch | win.k: s_mmin100 base / branch |
|---|---|---|---|---|---|---|---|---|---|---|
| 0 | 3508 | 0 | 3508 (0.3% unmoved) | 3508 (0.3% unmoved) | 75 | 75 | 17141 / 23316 | 23030 / 33200 | 39698 / 51117 | 21988 / 22279 |
| 1 | 3508 | 12416 | 3508 (0.3% unmoved) | 3508 (0.3% unmoved) | 75 | 75 | 8377 / 8352 | 11515 / 11546 | 25996 / 26144 | 22038 / 22000 |
| 2 | 1872 | 0 | 1872 (0.3% unmoved) | 1872 (0.3% unmoved) | 78 | 78 | 23592 / 10915 | 33873 / 14018 | 51378 / 29167 | 21888 / 22325 |
| 3 | 1872 | 2832 | 1872 (0.3% unmoved) | 1872 (0.3% unmoved) | 78 | 78 | 8502 / 8672 | 11559 / 11513 | 26399 / 26292 | 22070 / 22091 |
| 4 | 364 | 0 | 364 (0.3% unmoved) | 364 (0.3% unmoved) | 66 | 66 | 23111 / 17044 | 33272 / 22355 | 51298 / 38901 | 22176 / 21907 |
| 5 | 364 | 9632 | 364 (0.3% unmoved) | 364 (0.3% unmoved) | 66 | 66 | 8460 / 8371 | 11796 / 11489 | 26919 / 26458 | 22130 / 22461 |
| 6 | 2824 | 0 | 2824 (0.3% unmoved) | 2824 (0.3% unmoved) | 85 | 85 | 23165 / 16410 | 33295 / 22309 | 50871 / 38849 | 22071 / 22112 |
| 7 | 2824 | 48 | 2824 (0.3% unmoved) | 2824 (0.3% unmoved) | 85 | 85 | 8848 / 8697 | 11649 / 11634 | 26180 / 26621 | 22105 / 22052 |
| 8 | 1316 | 0 | 1316 (0.3% unmoved) | 1316 (0.3% unmoved) | 73 | 73 | 22905 / 22937 | 33204 / 33152 | 51694 / 51050 | |
| 9 | 1316 | 6800 | 1316 (0.3% unmoved) | 1316 (0.3% unmoved) | 73 | 73 | 8499 / 8508 | 11578 / 11519 | 26249 / 26430 | |
| 10 | 3776 | 0 | 3776 (0.3% unmoved) | 3776 (0.3% unmoved) | 72 | 72 | 23246 / 23557 | 33216 / 33150 | 51239 / 51091 | |
| 11 | 3776 | 13600 | 3776 (0.3% unmoved) | 3776 (0.3% unmoved) | 72 | 72 | 8411 / 8418 | 11503 / 11464 | 26333 / 26199 | |
| 12 | 2268 | 0 | 2268 (0.3% unmoved) | 2268 (0.3% unmoved) | 91 | 91 | 16991 / 23726 | 22584 / 33090 | 39347 / 51049 | |
| 13 | 2268 | 4016 | 2268 (0.3% unmoved) | 2268 (0.3% unmoved) | 91 | 91 | 8441 / 8440 | 11581 / 11780 | 26429 / 26468 | |
| 14 | 696 | 0 | 696 (0.3% unmoved) | 696 (0.3% unmoved) | 82 | 82 | 16144 / 16420 | 22967 / 22448 | 39124 / 39658 | |
| 15 | 696 | 10752 | 696 (0.3% unmoved) | 696 (0.3% unmoved) | 82 | 82 | 8674 / 8542 | 11460 / 11552 | 26297 / 26167 | |
| 16 | 3220 | 0 | 3220 (0.3% unmoved) | 3220 (0.3% unmoved) | 69 | 69 | 23120 / 23204 | 33262 / 33150 | 51170 / 51850 | |
| 17 | 3220 | 1184 | 3220 (0.3% unmoved) | 3220 (0.3% unmoved) | 69 | 69 | 8751 / 8475 | 11804 / 11468 | 26440 / 26631 | |
| 18 | 1712 | 0 | 1712 (0.3% unmoved) | 1712 (0.3% unmoved) | 59 | 59 | 23621 / 22949 | 33257 / 32994 | 50985 / 50965 | |
| 19 | 1712 | 7984 | 1712 (0.3% unmoved) | 1712 (0.3% unmoved) | 59 | 59 | 8430 / 8604 | 11492 / 11469 | 26395 / 26171 | |
| 20 | 76 | 0 | 76 (0.3% unmoved) | 76 (0.3% unmoved) | 70 | 70 | 21778 / 16415 | 30246 / 22591 | 47591 / 38913 | |
| 21 | 76 | 14720 | 76 (0.3% unmoved) | 76 (0.3% unmoved) | 70 | 70 | 8410 / 8397 | 11458 / 11431 | 26324 / 26107 | |
| 22 | 2664 | 0 | 2664 (0.3% unmoved) | 2664 (0.3% unmoved) | 84 | 84 | 22931 / 16371 | 33180 / 23382 | 51255 / 39659 | |
| 23 | 2664 | 5136 | 2664 (0.3% unmoved) | 2664 (0.3% unmoved) | 84 | 84 | 8703 / 8400 | 11635 / 11673 | 26305 / 26277 | |
| stock | - | - | 4092 (0.2% unmoved) | 4092 (0.2% unmoved) | 79 | 79 | 22918 / 19702 | 33181 / 26704 | 51643 / 43243 | 21975 / 22049 |

Region base: most common 0x300000000 in 46% of the first case's base runs.

Batches (variants, cases timed): 8 x 4, 12 x 3, 16 x 3, 20 x 3, 24 x 3; variants per case: 8: 1, 24: 3.
Builds and checks 0 s; timings 58 s (401 runs); load 2.18, 2.36, 2.36, 2.69, 2.69, 2.59, 2.59, 2.35, 2.35, 2.67 (start and end of each batch).

</details>

Raw timings: `/private/tmp/claude-501/-Users-dave-work-ngn-k-k/eb2f95d5-4068-4d95-8225-d12e510d750c/scratchpad/ld/lv/raw/20261004-161440.json`.

