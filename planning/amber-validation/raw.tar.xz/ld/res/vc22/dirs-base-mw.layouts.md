# Layout timings: `/private/tmp/claude-501/-Users-dave-work-ngn-k-k/eb2f95d5-4068-4d95-8225-d12e510d750c/scratchpad/hot/mw` against `/private/tmp/claude-501/-Users-dave-work-ngn-k-k/eb2f95d5-4068-4d95-8225-d12e510d750c/scratchpad/hot/base`

## Layout-randomised timings (designed: code and data)

Each case re-timed across designed variants of base and of branch (pbt/ldesign.py, seed 0). Pad j (an
unused function at the top of `src/0.c`) is built once and timed twice: at the stock data placement (colour 0)
and at a designed colour C_j (`AMBER_COLOUR`, a fork-only hook in the variant builds' `src/m.c`: each block of
64 KB or more moved c*(k+1) mod 16 KB into its slot). Pads and colours are one 2-D Kronecker sequence.
Base and branch of a variant run back to back (random order), 7 rounds after a first run of each;
the stock (unpadded, unhooked) builds as one more pair in the first batch (Stock layout; ** when measurable).
Adaptive: 8 variants, then 4 more at a time while the interval is wider than +-1.0%, up to 24.
Change: geometric mean of the per-variant median paired ratios branch/base (per pad first), with a t interval
over the pads (pads - 1 df); Stock data and Designed data: the same over each half alone.
Code: the largest range of the stock-data variants' medians within a batch (variants timed together; base /
branch) and the case's p-value (variant labels permuted within a batch's rounds, statistic the within-batch
sum of squares; the smaller of base's and branch's, doubled). Data: how much slower the stock data placement is than the designed one (stock / designed - 1 per pad:
median over the pads (base / branch), and the largest either way), and the p-value (sign-flip permutation within rounds). **code** / **data**: significant after Benjamini-Hochberg across the cases (q = 0.05) and over the
threshold (3%, 10% under 5 ms). Spread: the largest range of variant medians within a batch. Run: the run-to-run region base (ASLR) at
its most common address or not, the largest change it makes at one colour (max-|z| permutation test over the
colours, labels permuted within variants); when p < 0.05 each run is adjusted for it, per colour, for the tests, and each variant's change is
taken within categories (post-stratified).
Verdict: **change** when the interval excludes no change and the change is over the threshold; otherwise
placement when the stock change is measurable or the case is flagged; noise otherwise. Attributed "stock code
layout": the stock pair's change is measurable and its interval misses the stock-data variants' (they differ
from it in code only: no pad, no hook, the same data placement); data-dependent when the stock-data and designed-data changes differ (paired t over pads, p < 0.01, over the threshold).

Flagged (of 5 cases): code 0, data 3, run 2; change 4, data-dependent 3; stock code layout 0; intervals containing no change: 1.

| Case | Stock layout | Layout-averaged change | 95% interval | K | Stock data | Designed data | Code | Data | Spread | Run | Attributed | Verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| `win.k: s_msum100` | -57.9% (-70.6% to -49.4%) ** | -45.7% | -47.3% to -44.2% | 24 | -63.4% (-65.4% to -61.2%) | -19.6% (-20.2% to -19.0%) | 63.5% / 7.6% (p 0.23) | +88.6% / +1.3%, max 96.7% (p 0.0001) **data** | 115.3% / 9.1% | +46.9% at colour 0 (p 0.0001) **run**, adjusted | data+run | **change**, data-dependent |
| `win.k: s_mavg100` | -69.7% (-79.3% to -62.0%) ** | -62.7% | -64.6% to -60.6% | 24 | -76.5% (-78.9% to -73.8%) | -40.7% (-41.3% to -40.2%) | 137.8% / 3.7% (p 0.79) | +188.8% / +2.0%, max 193.0% (p 0.0001) **data** | 192.8% / 6.6% | (p 0.051) | data | **change**, data-dependent |
| `win.k: s_mdev100` | -56.7% (-67.1% to -50.1%) ** | -49.1% | -50.2% to -48.0% | 24 | -60.6% (-62.3% to -58.8%) | -34.2% (-34.7% to -33.8%) | 37.4% / 2.9% (p 0.13) | +46.8% / -0.7%, max 48.7% (p 0.0001) **data** | 70.3% / 5.0% | +33.8% at colour 0 (p 0.0001) **run**, adjusted | data+run | **change**, data-dependent |
| `win.k: s_mmin100` | -32.9% (-35.4% to -31.4%) ** | -32.7% | -33.2% to -32.2% | 12 | -32.4% (-33.0% to -31.7%) | -33.1% (-33.7% to -32.5%) | 1.3% / 3.4% (p 0.47) | -1.1% / +0.5%, max 1.9% (p 1) | 2.8% / 3.4% | (p 0.59) | - | **change** |
| `win.k: s_mmin10` | -0.7% (-2.5% to +2.0%) | +0.8% | -0.0% to +1.7% | 8 | -0.2% (-1.3% to +1.0%) | +1.9% (-0.4% to +4.2%) | 3.0% / 2.4% (p 0.46) | +1.1% / -0.1%, max 3.7% (p 0.16) | 3.6% / 2.7% | (p 1) | - | noise |

<details><summary>Design and variants</summary>

12 pads: 76, 364, 696, 1316, 1712, 1872, 2268, 2664, 2824, 3220, 3508, 3776; largest gap mod 4096 620 B (even: 341); 12 of 16 phases mod 64, 4 of 4 mod 16.
12 designed colours (and 0, the stock placement): 48, 1184, 2832, 4016, 5136, 6800, 7984, 9632, 10752, 12416, 13600, 14720; largest gap mod 16384 1664 B (even: 1260); 4 of 4 phases mod 64.

Shift: the most common move of a function against the pad-0 variant build (mod 4096) and the share of
functions not moved (an order file's pinned region); Loops: small loops straddling a 4 KB boundary.

| Variant | Pad | Colour | Base shift | Branch shift | Base loops | Branch loops | win.k: s_msum100 base / branch | win.k: s_mavg100 base / branch | win.k: s_mdev100 base / branch | win.k: s_mmin100 base / branch | win.k: s_mmin10 base / branch |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | 3508 | 0 | 3508 (0.3% unmoved) | 3508 (0.3% unmoved) | 91 | 99 | 22967 / 6911 | 33161 / 6932 | 51047 / 17107 | 21995 / 14853 | 12335 / 12326 |
| 1 | 3508 | 12416 | 3508 (0.3% unmoved) | 3508 (0.3% unmoved) | 91 | 99 | 8373 / 6689 | 11394 / 6764 | 26181 / 17284 | 22326 / 14987 | 12284 / 12474 |
| 2 | 1872 | 0 | 1872 (0.3% unmoved) | 1872 (0.3% unmoved) | 102 | 92 | 16388 / 6735 | 22199 / 6901 | 38580 / 17183 | 21827 / 14746 | 12506 / 12484 |
| 3 | 1872 | 2832 | 1872 (0.3% unmoved) | 1872 (0.3% unmoved) | 102 | 92 | 8268 / 6597 | 11445 / 6776 | 25872 / 17131 | 22150 / 14899 | 12306 / 12509 |
| 4 | 364 | 0 | 364 (0.3% unmoved) | 364 (0.3% unmoved) | 88 | 93 | 16684 / 6804 | 22706 / 6891 | 38836 / 17123 | 22016 / 14837 | 12634 / 12624 |
| 5 | 364 | 9632 | 364 (0.3% unmoved) | 364 (0.3% unmoved) | 88 | 93 | 8548 / 6636 | 11731 / 6773 | 26494 / 17050 | 22034 / 14791 | 12186 / 12635 |
| 6 | 2824 | 0 | 2824 (0.3% unmoved) | 2824 (0.3% unmoved) | 85 | 92 | 23193 / 6825 | 33480 / 6963 | 50915 / 17268 | 22009 / 15222 | 12265 / 12495 |
| 7 | 2824 | 48 | 2824 (0.3% unmoved) | 2824 (0.3% unmoved) | 85 | 92 | 8400 / 6994 | 11425 / 7063 | 26131 / 17444 | 22438 / 15065 | 12197 / 12298 |
| 8 | 1316 | 0 | 1316 (0.3% unmoved) | 1316 (0.3% unmoved) | 79 | 81 | 22965 / 6975 | 33157 / 6929 | 51374 / 17040 | 22183 / 15070 | |
| 9 | 1316 | 6800 | 1316 (0.3% unmoved) | 1316 (0.3% unmoved) | 79 | 81 | 8270 / 6568 | 11427 / 6776 | 26316 / 17111 | 22355 / 14832 | |
| 10 | 3776 | 0 | 3776 (0.3% unmoved) | 3776 (0.3% unmoved) | 77 | 93 | 23921 / 6677 | 33155 / 6864 | 51528 / 17074 | 22181 / 14894 | |
| 11 | 3776 | 13600 | 3776 (0.3% unmoved) | 3776 (0.3% unmoved) | 77 | 93 | 8336 / 6581 | 11486 / 6719 | 26046 / 17145 | 22004 / 14786 | |
| 12 | 2268 | 0 | 2268 (0.3% unmoved) | 2268 (0.3% unmoved) | 77 | 72 | 23363 / 6830 | 33201 / 6890 | 50877 / 17385 | | |
| 13 | 2268 | 4016 | 2268 (0.3% unmoved) | 2268 (0.3% unmoved) | 77 | 72 | 8381 / 6669 | 11376 / 6679 | 26338 / 17189 | | |
| 14 | 696 | 0 | 696 (0.3% unmoved) | 696 (0.3% unmoved) | 92 | 90 | 23004 / 6788 | 33305 / 6857 | 51638 / 16933 | | |
| 15 | 696 | 10752 | 696 (0.3% unmoved) | 696 (0.3% unmoved) | 92 | 90 | 8357 / 6726 | 11418 / 6749 | 26085 / 17202 | | |
| 16 | 3220 | 0 | 3220 (0.3% unmoved) | 3220 (0.3% unmoved) | 61 | 55 | 16807 / 6834 | 22527 / 6951 | 39321 / 16999 | | |
| 17 | 3220 | 1184 | 3220 (0.3% unmoved) | 3220 (0.3% unmoved) | 61 | 55 | 8401 / 6677 | 11448 / 6751 | 26193 / 17070 | | |
| 18 | 1712 | 0 | 1712 (0.3% unmoved) | 1712 (0.3% unmoved) | 86 | 83 | 22980 / 6755 | 33138 / 6861 | 51272 / 17035 | | |
| 19 | 1712 | 7984 | 1712 (0.3% unmoved) | 1712 (0.3% unmoved) | 86 | 83 | 8395 / 6738 | 11469 / 6826 | 26091 / 17034 | | |
| 20 | 76 | 0 | 76 (0.3% unmoved) | 76 (0.3% unmoved) | 84 | 78 | 23056 / 6816 | 33111 / 6910 | 51235 / 17291 | | |
| 21 | 76 | 14720 | 76 (0.3% unmoved) | 76 (0.3% unmoved) | 84 | 78 | 8456 / 6801 | 11481 / 6691 | 25925 / 17206 | | |
| 22 | 2664 | 0 | 2664 (0.3% unmoved) | 2664 (0.3% unmoved) | 91 | 91 | 21655 / 6809 | 29658 / 6884 | 46410 / 17096 | | |
| 23 | 2664 | 5136 | 2664 (0.3% unmoved) | 2664 (0.3% unmoved) | 91 | 91 | 8358 / 6720 | 11440 / 6784 | 26149 / 17180 | | |
| stock | - | - | 4092 (0.1% unmoved) | 4092 (0.1% unmoved) | 79 | 82 | 16809 / 6768 | 22769 / 6928 | 39011 / 16997 | 22130 / 14846 | 12501 / 12503 |

Region base: most common 0x300000000 in 51% of the first case's base runs.

Batches (variants, cases timed): 8 x 5, 12 x 4, 16 x 3, 20 x 3, 24 x 3; variants per case: 8: 1, 12: 1, 24: 3.
Builds and checks 0 s; timings 66 s (465 runs); load 2.40, 2.31, 2.31, 2.27, 2.27, 2.36, 2.36, 2.29, 2.29, 2.40 (start and end of each batch).

</details>

Raw timings: `/private/tmp/claude-501/-Users-dave-work-ngn-k-k/eb2f95d5-4068-4d95-8225-d12e510d750c/scratchpad/ld/lv/raw/20261004-170843.json`.

