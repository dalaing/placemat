# Layout timings: `/private/tmp/claude-501/-Users-dave-work-ngn-k-k/eb2f95d5-4068-4d95-8225-d12e510d750c/scratchpad/of/C2` against `/private/tmp/claude-501/-Users-dave-work-ngn-k-k/eb2f95d5-4068-4d95-8225-d12e510d750c/scratchpad/of/A`

## Layout-randomised timings (designed: code and data)

Each case re-timed across designed variants of base and of branch (pbt/ldesign.py, seed 0).
Variant i has pad i (an unused function at the top of `src/0.c`) and no data hook (--no-data).
Base and branch of a variant run back to back (random order), 7 rounds after a first run of each;
the stock (unpadded, unhooked) builds as one more pair in the first batch (Stock layout; ** when measurable).
Adaptive: 8 variants, then 4 more at a time while the interval is wider than +-1.0%, up to 8.
Change: geometric mean of the per-variant median paired ratios branch/base (per pad first), with a t interval
over the pads (pads - 1 df).
Code: the largest range of the stock-data variants' medians within a batch (variants timed together; base /
branch), the slowest against their median (worst of base and branch), and the case's p-value (labels permuted within a batch's rounds, statistic the within-batch
sum of squares; the smaller of base's and branch's, doubled).
**code** / **data**: significant after Benjamini-Hochberg across the cases (q = 0.05) and over the
threshold (3%, 10% under 5 ms). Spread: the largest range of variant medians within a batch. Run: the run-to-run region base (ASLR) at
its most common address or not, the largest change it makes at one colour (max-|z| permutation test over the
colours, labels permuted within variants); when p < 0.05 each run is adjusted for it, per colour, for the tests, and each variant's change is
taken within categories (post-stratified).
Verdict: **change** when the interval excludes no change and the change is over the threshold; otherwise
placement when the stock change is measurable or the case is flagged; noise otherwise. Attributed "stock code
layout": the stock pair's change is measurable and its interval misses the stock-data variants' (they differ
from it in code only: no pad, no hook, the same data placement).

Flagged (of 8 cases): code 5, data 0, run 0; change 0; stock code layout 0; intervals containing no change: 8.

| Case | Stock layout | Layout-averaged change | 95% interval | K | Code | Spread | Run | Attributed | Verdict |
|---|---|---|---|---|---|---|---|---|---|
| `microbench: setdictbig` (series) | -2.9% (-5.2% to +1.7%) | -7.9% | -24.9% to +13.0% | 8 | 98.6% / 3.2%, worst +97.8% (p 0.0001) **code** | 98.6% / 3.2% | (p 1) | code | placement |
| `microbench: setdictbigall` (series) | +0.0% (-1.4% to +1.6%) | -8.6% | -25.4% to +12.1% | 8 | 99.6% / 2.0%, worst +98.5% (p 0.0002) **code** | 99.6% / 2.0% | (p 1) | code | placement |
| `microbench: setdictbigname` (series) | -0.1% (-1.1% to +0.6%) | -8.4% | -25.1% to +12.0% | 8 | 104.5% / 1.5%, worst +104.1% (p 0.0001) **code** | 104.5% / 1.5% | (p 1) | code | placement |
| `microbench: chargrade` (series) | -2.0% (-3.9% to +1.0%) | -3.2% | -10.7% to +5.0% | 8 | 34.4% / 3.3%, worst +32.6% (p 0.0001) **code** | 34.4% / 3.3% | (p 1) | code | placement |
| `microbench: takekeys10x10` (series) | -0.5% (-1.3% to -0.3%) | -2.0% | -6.4% to +2.7% | 8 | 18.7% / 2.2%, worst +18.0% (p 0.0001) **code** | 18.7% / 2.2% | (p 1) | code | placement |
| `microbench: grade` | +0.6% (-1.0% to +2.3%) | +0.5% | -0.9% to +1.8% | 8 | 3.5% / 3.3%, worst +2.7% (p 0.63) | 3.5% / 3.3% | (p 1) | - | noise |
| `microbench: fsum` (series) | -0.8% (-2.2% to +2.1%) | +0.1% | -0.5% to +0.6% | 8 | 1.8% / 2.7%, worst +2.3% (p 0.63) | 1.8% / 2.7% | (p 1) | - | noise |
| `fnd.k: sc_member` | -0.3% (-3.5% to +3.1%) | +0.0% | -0.8% to +0.8% | 8 | 2.0% / 1.4%, worst +1.0% (p 1) | 2.0% / 1.4% | (p 1) | - | noise |

<details><summary>Design and variants</summary>

8 pads: 600, 1150, 1200, 1256, 1316, 3260, 3304, 3400; largest gap mod 4096 1944 B (even: 512); 7 of 16 phases mod 64, 5 of 4 mod 16.

Shift: the most common move of a function against the pad-0 variant build (mod 4096) and the share of
functions not moved (an order file's pinned region); Loops: small loops straddling a 4 KB boundary.

| Variant | Pad | Colour | Base shift | Branch shift | Base loops | Branch loops | microbench: setdictbig base / branch | microbench: setdictbigall base / branch | microbench: setdictbigname base / branch | microbench: chargrade base / branch | microbench: takekeys10x10 base / branch | microbench: grade base / branch | microbench: fsum base / branch | fnd.k: sc_member base / branch |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | 1150 | 0 | 1152 (0.3% unmoved) | 1152 (17.5% unmoved) | 68 | 58 | 5959 / 5999 | 6194 / 6012 | 5980 / 6036 | 34152 / 34734 | 44345 / 44550 | 36726 / 35814 | 23236 / 23166 | 23396 / 23141 |
| 1 | 1200 | 0 | 1200 (0.3% unmoved) | 1200 (17.5% unmoved) | 77 | 60 | 6042 / 5949 | 6025 / 6000 | 6127 / 6020 | 34065 / 34363 | 43882 / 43765 | 36117 / 36405 | 22877 / 22997 | 23116 / 23173 |
| 2 | 1256 | 0 | 1256 (0.3% unmoved) | 1248 (17.5% unmoved) | 87 | 65 | 11872 / 5997 | 12016 / 6002 | 12238 / 6061 | 34488 / 33748 | 52028 / 43874 | 35580 / 36745 | 22812 / 22885 | 23366 / 23065 |
| 3 | 1316 | 0 | 1316 (0.3% unmoved) | 1312 (17.5% unmoved) | 91 | 84 | 6055 / 5987 | 6009 / 5984 | 5994 / 5991 | 34648 / 34185 | 44677 / 44177 | 35591 / 36072 | 22813 / 22862 | 23220 / 23114 |
| 4 | 3260 | 0 | 3260 (0.3% unmoved) | 3248 (17.5% unmoved) | 62 | 56 | 5972 / 5972 | 6052 / 5973 | 5978 / 5989 | 34611 / 34056 | 43776 / 43702 | 35459 / 35925 | 23156 / 22794 | 23574 / 23167 |
| 5 | 3304 | 0 | 3304 (0.3% unmoved) | 3296 (17.5% unmoved) | 69 | 51 | 5954 / 5977 | 6054 / 6021 | 5973 / 5996 | 45657 / 34887 | 43846 / 43577 | 35916 / 36126 | 23108 / 22847 | 23117 / 23106 |
| 6 | 3400 | 0 | 3400 (0.3% unmoved) | 3392 (17.5% unmoved) | 68 | 42 | 6021 / 6138 | 6187 / 6031 | 6069 / 5969 | 33798 / 33828 | 44175 / 44276 | 36110 / 36807 | 22954 / 23408 | 23433 / 23383 |
| 7 | 600 | 0 | 600 (0.3% unmoved) | 592 (17.5% unmoved) | 83 | 63 | 5984 / 5972 | 5989 / 6090 | 6001 / 6057 | 34399 / 34200 | 44009 / 43904 | 35534 / 35598 | 23108 / 22885 | 23450 / 23213 |
| stock | - | - | 4092 (0.1% unmoved) | 4080 (17.4% unmoved) | 79 | 57 | 6143 / 5976 | 5999 / 5962 | 6007 / 5989 | 34471 / 34022 | 44834 / 44283 | 35881 / 35869 | 23226 / 23134 | 23151 / 23144 |

Batches (variants, cases timed): 8 x 8; variants per case: 8: 8.
Builds and checks 90 s; timings 111 s (290 runs); load 2.98, 7.03 (start and end of each batch).

</details>

Raw timings: `/private/tmp/claude-501/-Users-dave-work-ngn-k-k/eb2f95d5-4068-4d95-8225-d12e510d750c/scratchpad/ld/lv/raw/20261004-175055.json`.

