# Layout timings: `main`

Base `main` (7dcf56e61), branch 7dcf56e61.

## Layout-randomised timings (designed: code and data)

Each case re-timed across designed variants of base and of branch (pbt/ldesign.py, seed 0): variant i has
the code pad of pad i//2 (an unused function at the top of `src/0.c`) and the data colour of colour (i+1)//2
(`AMBER_COLOUR`: each block of 64 KB or more moved c*(k+1) mod 16 KB into its slot, a fork-only hook in the
variant builds' `src/m.c`), so each pad is timed under two colours (a data contrast) and each colour under two
pads (a code contrast).
Base and branch of a variant run back to back (random order), 7 rounds after a first run of each;
the stock (unpadded, unhooked) builds as one more pair in the first batch (Stock layout; ** when measurable).
Adaptive: 8 variants, then 4 more at a time while the interval is wider than +-1.0%, up to 24.
Change: geometric mean over variants of the median paired ratio branch/base; 95% interval t-based (variants
sharing a pad summed, the shared-colour covariance added, m-1 df for m pads). Code / Data: the largest
contrast of variant medians (base / branch) and the case's p-value (sign-flip permutation within rounds,
the smaller of base's and branch's, doubled); **code** / **data** when significant after Benjamini-Hochberg
across the cases at q = 0.05 and the contrast is over the threshold (3%, 10% under 5 ms). Spread: range of
variant medians; Worst: the slowest variant against the median (base / branch). Run: the run-to-run region
base (ASLR), at its most common address or not: the change in time it makes, labels permuted within variants;
when p < 0.05 each run is adjusted for it (a covariate) before the change and the code and data tests.
Verdict: **change** when the interval excludes no change and the change is over the threshold; otherwise
placement when the stock change is measurable or the case is flagged; noise otherwise.

Flagged: code 0, data 0, run 0 of 4 cases; change 0.

| Case | Stock layout | Layout-averaged change | 95% interval | K | Code | Data | Spread | Worst | Run | Attributed | Verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|
| `win.k: s_msum100` | -19.5% (-30.5% to +13.6%) | -0.2% | -1.1% to +0.6% | 12 | 2.3% / 1.8% (p 0.6) | 3.4% / 2.2% (p 0.49) | 3.4% / 2.9% | +2.4% / +2.3% | -0.3% (p 1) | - | noise |
| `win.k: s_mavg100` | -20.7% (-32.3% to +12.0%) | -0.2% | -1.1% to +0.8% | 8 | 3.0% / 1.2% (p 0.24) | 1.9% / 1.0% (p 0.47) | 3.1% / 1.4% | +2.1% / +0.8% | -0.9% (p 0.079) | - | noise |
| `win.k: s_mdev100` | -12.8% (-25.1% to +5.4%) | +0.0% | -0.9% to +1.0% | 8 | 1.6% / 0.2% (p 0.36) | 1.6% / 1.1% (p 0.33) | 1.9% / 1.2% | +0.9% / +0.6% | -0.6% (p 0.34) | - | noise |
| `win.k: s_mmin100` | -0.3% (-1.6% to +0.3%) | +0.4% | -0.4% to +1.1% | 12 | 2.2% / 3.2% (p 0.074) | 2.7% / 2.0% (p 0.085) | 2.8% / 3.2% | +2.0% / +2.1% | +0.6% (p 0.2) | - | noise |

<details><summary>Design and variants</summary>

6 pads: 364, 1316, 1872, 2824, 3508, 3776; largest gap mod 4096 952 B (even: 682); 6 of 16 phases mod 64, 4 of 4 mod 16.
7 colours: 48, 2832, 4016, 6800, 9632, 12416, 13600; largest gap mod 16384 2832 B (even: 2340); 4 of 4 phases mod 64.

Shift: the most common move of a function against the hooked unpadded build (mod 4096) and the share of
functions not moved (an order file's pinned region); Loops: small loops straddling a 4 KB boundary.

| Variant | Pad | Colour | Base shift | Branch shift | Base loops | Branch loops | win.k: s_msum100 base / branch | win.k: s_mavg100 base / branch | win.k: s_mdev100 base / branch | win.k: s_mmin100 base / branch |
|---|---|---|---|---|---|---|---|---|---|---|
| 0 | 3508 | 12416 | 3508 (0.3% unmoved) | 3508 (0.3% unmoved) | 75 | 75 | 8563 / 8350 | 11697 / 11531 | 26378 / 26418 | 21845 / 22047 |
| 1 | 3508 | 2832 | 3508 (0.3% unmoved) | 3508 (0.3% unmoved) | 75 | 75 | 8533 / 8436 | 11654 / 11597 | 26248 / 26153 | 21800 / 21991 |
| 2 | 1872 | 2832 | 1872 (0.3% unmoved) | 1872 (0.3% unmoved) | 78 | 78 | 8415 / 8533 | 11496 / 11459 | 26094 / 26170 | 21916 / 21980 |
| 3 | 1872 | 9632 | 1872 (0.3% unmoved) | 1872 (0.3% unmoved) | 78 | 78 | 8347 / 8347 | 11554 / 11488 | 26528 / 26458 | 21954 / 22341 |
| 4 | 364 | 9632 | 364 (0.3% unmoved) | 364 (0.3% unmoved) | 66 | 66 | 8437 / 8315 | 11480 / 11546 | 26109 / 26401 | 22049 / 21898 |
| 5 | 364 | 48 | 364 (0.3% unmoved) | 364 (0.3% unmoved) | 66 | 66 | 8470 / 8347 | 11469 / 11435 | 26034 / 26191 | 22097 / 22024 |
| 6 | 2824 | 48 | 2824 (0.3% unmoved) | 2824 (0.3% unmoved) | 85 | 85 | 8334 / 8315 | 11825 / 11518 | 26359 / 26253 | 22079 / 22063 |
| 7 | 2824 | 6800 | 2824 (0.3% unmoved) | 2824 (0.3% unmoved) | 85 | 85 | 8354 / 8313 | 11607 / 11445 | 26456 / 26371 | 22312 / 22508 |
| 8 | 1316 | 6800 | 1316 (0.3% unmoved) | 1316 (0.3% unmoved) | 73 | 73 | 8341 / 8372 | | | 21839 / 21801 |
| 9 | 1316 | 13600 | 1316 (0.3% unmoved) | 1316 (0.3% unmoved) | 73 | 73 | 8421 / 8405 | | | 21987 / 21831 |
| 10 | 3776 | 13600 | 3776 (0.3% unmoved) | 3776 (0.3% unmoved) | 72 | 72 | 8618 / 8555 | | | 22415 / 22218 |
| 11 | 3776 | 4016 | 3776 (0.3% unmoved) | 3776 (0.3% unmoved) | 72 | 72 | 8333 / 8371 | | | 21822 / 22066 |
| stock | - | - | 4092 (0.2% unmoved) | 4092 (0.2% unmoved) | 79 | 79 | 23229 / 16329 | 33071 / 22395 | 51046 / 38939 | 22264 / 22082 |

Region base: most common 0x300000000 in 38% of the first case's base runs.

Batches (variants, cases timed): 8 x 4, 12 x 2; variants per case: 8: 2, 12: 2.
Builds and checks 35 s; timings 29 s (209 runs); load 2.85, 2.81, 2.74, 2.71 (start and end of each batch).

</details>

