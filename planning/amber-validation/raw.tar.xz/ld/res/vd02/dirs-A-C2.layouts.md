# Layout timings: `/private/tmp/claude-501/-Users-dave-work-ngn-k-k/eb2f95d5-4068-4d95-8225-d12e510d750c/scratchpad/of/C2` against `/private/tmp/claude-501/-Users-dave-work-ngn-k-k/eb2f95d5-4068-4d95-8225-d12e510d750c/scratchpad/of/A`

## Layout-randomised timings (designed: code and data)

Each case re-timed across designed variants of base and of branch (pbt/ldesign.py, seed 0).
Variant i has pad i (an unused function at the top of `src/0.c`) and no data hook (--no-data).
Base and branch of a variant run back to back (random order), 7 rounds after a first run of each;
the stock (unpadded, unhooked) builds as one more pair in the first batch (Stock layout; ** when measurable).
Adaptive: 8 variants, then 4 more at a time while the interval is wider than +-1.0%, up to 24.
Change: geometric mean of the per-variant median paired ratios branch/base (per pad first), with a t interval
over the pads (pads - 1 df).
Code: the largest range of the stock-data variants' medians within a batch (variants timed together; base /
branch), the slowest against their median (worst of base and branch), and the case's p-value (labels permuted within a batch's rounds, statistic the within-batch
sum of squares; the smaller of base's and branch's, doubled).
**code** / **data**: significant after Benjamini-Hochberg across the cases (q = 0.05) and over the
threshold (3%, 10% under 5 ms). Spread: the largest range of variant medians within a batch. Run: the run-to-run region base (ASLR) at
its most common address or not, the largest change it makes at one colour (max-|z| permutation test over the
colours, labels permuted within variants); when p < 0.05 each run is adjusted for it, per colour, for the tests, and each variant's change is
taken within categories (post-stratified).
Verdict: **change** when the interval excludes no change and the change is over the threshold; otherwise
placement when the stock change is measurable or the case is flagged; noise otherwise. Attributed "stock code
layout": the stock pair's change is measurable and its interval misses the stock-data variants' (they differ
from it in code only: no pad, no hook, the same data placement).

Flagged (of 30 cases): code 3, data 0, run 0; change 0; stock code layout 1; intervals containing no change: 25.

| Case | Stock layout | Layout-averaged change | 95% interval | K | Code | Spread | Run | Attributed | Verdict |
|---|---|---|---|---|---|---|---|---|---|
| `microbench: setdictbig` (series) | -0.4% (-2.7% to +1.7%) | -0.2% | -0.8% to +0.5% | 8 | 2.1% / 4.2%, worst +3.7% (p 0.53) | 2.1% / 4.2% | (p 1) | - | noise |
| `microbench: setdictbigrows` (series) | -0.6% (-1.6% to +0.3%) | -0.3% | -1.2% to +0.6% | 8 | 3.1% / 4.5%, worst +4.1% (p 0.17) | 3.1% / 4.5% | (p 1) | - | noise |
| `microbench: setdictbigall` (series) | +0.6% (-1.4% to +0.7%) | +0.1% | -0.6% to +0.7% | 8 | 1.5% / 2.4%, worst +1.5% (p 0.66) | 1.5% / 2.4% | (p 1) | - | noise |
| `microbench: setdictbigkeys` (series) | +1.9% (+0.8% to +4.1%) | -0.2% | -1.0% to +0.7% | 12 | 3.7% / 3.2%, worst +1.3% (p 0.39) | 3.7% / 3.2% | (p 1) | - | noise |
| `microbench: setdictbigname` (series) | -2.1% (-3.4% to -0.1%) | -0.1% | -0.9% to +0.8% | 12 | 3.6% / 4.3%, worst +2.7% (p 0.7) | 3.6% / 4.3% | (p 1) | - | noise |
| `microbench: chargrade` (series) | +1.4% (-1.2% to +4.6%) | -0.1% | -1.0% to +0.9% | 20 | 6.9% / 9.8%, worst +4.9% (p 0.74) | 6.9% / 9.8% | (p 1) | - | noise |
| `microbench: takekeys10x10` (series) | -1.8% (-2.2% to +1.2%) | -0.2% | -0.7% to +0.3% | 8 | 2.6% / 1.3%, worst +1.4% (p 0.31) | 2.6% / 1.3% | (p 1) | - | noise |
| `microbench: setdictflat` (series) | -0.9% (-2.1% to -0.3%) | -2.7% | -3.6% to -1.8% | 12 | 6.1% / 3.1%, worst +2.4% (p 0.058) | 6.1% / 3.1% | (p 1) | - | noise |
| `microbench: setdictverb` (series) | -0.7% (-3.4% to +3.2%) | -0.6% | -1.5% to +0.2% | 16 | 4.7% / 7.4%, worst +5.0% (p 0.08) | 4.7% / 7.4% | (p 1) | - | noise |
| `microbench: setdictrows` (series) | +0.7% (-1.7% to +2.3%) | -0.4% | -1.2% to +0.5% | 24 | 6.1% / 4.8%, worst +2.8% (p 0.0003) **code** | 6.1% / 4.8% | (p 1) | code | placement |
| `microbench: setdictnest` (series) | -1.0% (-3.9% to +2.3%) | -0.9% | -1.8% to +0.1% | 20 | 7.6% / 7.4%, worst +3.5% (p 0.078) | 7.6% / 7.4% | (p 1) | - | noise |
| `microbench: tillists` (series) | -0.3% (-0.9% to +1.9%) | +1.9% | +1.1% to +2.8% | 12 | 2.2% / 4.5%, worst +1.6% (p 0.0022) **code** | 2.2% / 4.5% | (p 1) | code | placement |
| `microbench: takecols` (series) | +0.4% (-1.1% to +1.2%) | +0.2% | -0.5% to +1.0% | 8 | 2.4% / 1.3%, worst +1.9% (p 0.3) | 2.4% / 1.3% | (p 1) | - | noise |
| `microbench: fdistinctshort` (series) | -3.7% (-4.3% to +0.2%) | -1.0% | -1.9% to -0.0% | 16 | 5.8% / 3.5%, worst +2.8% (p 0.0019) **code** | 5.8% / 3.5% | (p 1) | code | placement |
| `microbench: genericdistinct` (series) | -0.6% (-1.6% to +1.0%) | -0.4% | -1.0% to +0.1% | 8 | 0.9% / 1.0%, worst +0.8% (p 0.22) | 0.9% / 1.0% | (p 1) | - | noise |
| `microbench: settableverb` (series) | -1.7% (-2.2% to +4.4%) | -0.8% | -1.7% to +0.2% | 12 | 4.2% / 3.9%, worst +2.5% (p 0.58) | 4.2% / 3.9% | (p 1) | - | noise |
| `microbench: grade` | +1.3% (+0.1% to +2.7%) | +0.6% | -0.2% to +1.5% | 8 | 2.2% / 3.6%, worst +2.8% (p 0.92) | 2.2% / 3.6% | (p 1) | - | noise |
| `microbench: igradedown` | +0.3% (-0.2% to +1.0%) | +0.2% | -0.6% to +0.9% | 8 | 2.1% / 3.5%, worst +2.7% (p 0.19) | 2.1% / 3.5% | (p 1) | - | noise |
| `microbench: fsum` (series) | -0.6% (-2.4% to +0.3%) | +0.4% | -0.1% to +1.0% | 8 | 0.7% / 2.7%, worst +2.0% (p 0.28) | 0.7% / 2.7% | (p 1) | - | noise |
| `microbench: fgroup` | +0.1% (-1.1% to +0.6%) | -0.1% | -0.5% to +0.3% | 8 | 1.0% / 1.0%, worst +0.6% (p 0.14) | 1.0% / 1.0% | (p 1) | - | noise |
| `microbench: dategrade` (series) | -0.5% (-2.4% to +2.8%) | -0.7% | -1.6% to +0.1% | 16 | 5.3% / 8.9%, worst +3.2% (p 0.24) | 5.3% / 8.9% | (p 1) | - | noise |
| `microbench: jsonints` (series) | -0.0% (-0.3% to +2.3%) | +0.2% | -0.7% to +1.0% | 12 | 6.9% / 5.4%, worst +3.8% (p 0.68) | 6.9% / 5.4% | (p 1) | - | noise |
| `grp.k: s_grp10` | -0.7% (-1.1% to -0.1%) | -0.1% | -0.5% to +0.3% | 8 | 1.9% / 2.1%, worst +1.1% (p 0.99) | 1.9% / 2.1% | (p 1) | - | noise |
| `grp.k: s_grp100k` | +0.5% (-0.3% to +2.7%) | +0.2% | -0.1% to +0.5% | 8 | 0.9% / 2.1%, worst +1.6% (p 0.64) | 0.9% / 2.1% | (p 1) | - | noise |
| `grp.k: sc_qsql_select` | +3.0% (+0.2% to +3.8%) ** | -0.5% | -0.9% to -0.1% | 8 | 1.8% / 3.6%, worst +3.1% (p 0.64) | 1.8% / 3.6% | (p 1) | stock code layout | placement |
| `fnd.k: sc_member` | -0.0% (-0.6% to +1.3%) | -0.9% | -1.8% to -0.0% | 8 | 2.5% / 2.0%, worst +1.7% (p 0.33) | 2.5% / 2.0% | (p 1) | - | noise |
| `win.k: s_msum100` | -8.1% (-21.4% to +4.0%) | -1.3% | -8.4% to +6.3% | 24 | 75.3% / 44.9%, worst +45.5% (p 0.33) | 75.3% / 44.9% | (p 1) | - | noise |
| `win.k: s_mavg100` | -9.4% (-26.9% to -0.2%) ** | -0.4% | -8.1% to +7.9% | 24 | 83.6% / 53.0%, worst +50.8% (p 0.38) | 83.6% / 53.0% | (p 1) | - | placement |
| `win.k: s_mdev100` | -5.0% (-21.2% to +1.9%) | -0.1% | -5.5% to +5.7% | 24 | 55.4% / 39.9%, worst +30.9% (p 0.36) | 55.4% / 39.9% | (p 1) | - | noise |
| `win.k: s_mmin100` | -2.2% (-3.4% to +0.7%) | -0.5% | -1.2% to +0.3% | 12 | 3.6% / 3.8%, worst +2.0% (p 0.017) | 3.6% / 3.8% | (p 1) | - | noise |

<details><summary>Design and variants</summary>

24 pads: 76, 248, 364, 472, 696, 868, 1028, 1316, 1424, 1712, 1820, 1872, 2044, 2268, 2376, 2664, 2824, 2996, 3220, 3328, 3508, 3616, 3776, 4012; largest gap mod 4096 288 B (even: 170); 16 of 16 phases mod 64, 4 of 4 mod 16.

Shift: the most common move of a function against the pad-0 variant build (mod 4096) and the share of
functions not moved (an order file's pinned region); Loops: small loops straddling a 4 KB boundary.

| Variant | Pad | Colour | Base shift | Branch shift | Base loops | Branch loops | microbench: setdictbig base / branch | microbench: setdictbigrows base / branch | microbench: setdictbigall base / branch | microbench: setdictbigkeys base / branch | microbench: setdictbigname base / branch | microbench: chargrade base / branch | microbench: takekeys10x10 base / branch | microbench: setdictflat base / branch | microbench: setdictverb base / branch | microbench: setdictrows base / branch | microbench: setdictnest base / branch | microbench: tillists base / branch | microbench: takecols base / branch | microbench: fdistinctshort base / branch | microbench: genericdistinct base / branch | microbench: settableverb base / branch | microbench: grade base / branch | microbench: igradedown base / branch | microbench: fsum base / branch | microbench: fgroup base / branch | microbench: dategrade base / branch | microbench: jsonints base / branch | grp.k: s_grp10 base / branch | grp.k: s_grp100k base / branch | grp.k: sc_qsql_select base / branch | fnd.k: sc_member base / branch | win.k: s_msum100 base / branch | win.k: s_mavg100 base / branch | win.k: s_mdev100 base / branch | win.k: s_mmin100 base / branch |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | 3508 | 0 | 3508 (0.3% unmoved) | 3504 (17.5% unmoved) | 94 | 54 | 5943 / 5960 | 6022 / 6015 | 6003 / 6053 | 10744 / 10690 | 6161 / 6067 | 34319 / 36230 | 44756 / 44399 | 15617 / 15386 | 20564 / 20529 | 25380 / 25441 | 17806 / 17755 | 16077 / 16202 | 41284 / 41305 | 33377 / 32675 | 106633 / 105333 | 23502 / 22899 | 34842 / 35288 | 39181 / 39435 | 22849 / 22976 | 266761 / 266119 | 1272 / 1253 | 7720 / 7860 | 23257 / 23507 | 29688 / 29610 | 19362 / 19217 | 23702 / 23192 | 23063 / 23116 | 33115 / 33153 | 51164 / 51395 | 21825 / 22217 |
| 1 | 1872 | 0 | 1872 (0.3% unmoved) | 1872 (17.5% unmoved) | 85 | 49 | 6005 / 6014 | 6138 / 5976 | 6071 / 5979 | 10670 / 10494 | 6011 / 6247 | 34326 / 34500 | 44015 / 44215 | 15590 / 15205 | 20809 / 19969 | 24794 / 25234 | 17980 / 17687 | 15896 / 15880 | 41451 / 41663 | 33316 / 33129 | 105783 / 106279 | 23465 / 23086 | 34785 / 34820 | 39892 / 39306 | 22886 / 22779 | 266042 / 265114 | 1261 / 1269 | 8023 / 7732 | 23160 / 23572 | 29628 / 29600 | 19306 / 19260 | 23126 / 23187 | 23027 / 23042 | 33066 / 33069 | 51043 / 51355 | 22062 / 21941 |
| 2 | 364 | 0 | 364 (0.3% unmoved) | 352 (17.5% unmoved) | 82 | 44 | 6067 / 6214 | 5978 / 6245 | 6019 / 6121 | 10591 / 10696 | 6156 / 6078 | 33977 / 34415 | 44611 / 44175 | 15327 / 15037 | 20189 / 20460 | 25689 / 25384 | 17750 / 17378 | 16035 / 16301 | 41217 / 41676 | 33584 / 32790 | 106093 / 105299 | 23019 / 23181 | 35030 / 36077 | 39366 / 40324 | 22961 / 23402 | 265097 / 267781 | 1270 / 1254 | 7726 / 7769 | 23087 / 23196 | 29638 / 30080 | 19645 / 19842 | 23573 / 23583 | 17097 / 20423 | 23405 / 28379 | 39170 / 45169 | 22021 / 22410 |
| 3 | 2824 | 0 | 2824 (0.3% unmoved) | 2816 (17.5% unmoved) | 98 | 50 | 5995 / 6077 | 5955 / 5982 | 5997 / 6020 | 10832 / 10768 | 6222 / 6256 | 34269 / 34294 | 45182 / 44704 | 15623 / 14908 | 20714 / 20301 | 24711 / 24988 | 17999 / 18021 | 16026 / 16613 | 42012 / 41149 | 34184 / 32860 | 106269 / 105567 | 22968 / 22954 | 34877 / 35586 | 39716 / 40302 | 22808 / 22952 | 267570 / 266166 | 1239 / 1266 | 7893 / 7762 | 23064 / 23089 | 29408 / 29486 | 19474 / 19449 | 23622 / 23186 | 23138 / 22926 | 33242 / 33168 | 51469 / 51141 | 22216 / 21901 |
| 4 | 1316 | 0 | 1316 (0.3% unmoved) | 1312 (17.5% unmoved) | 91 | 84 | 5993 / 5997 | 6047 / 6052 | 6023 / 6108 | 10729 / 10435 | 6003 / 5993 | 35050 / 34709 | 44535 / 44357 | 15725 / 15163 | 20572 / 20099 | 25815 / 24925 | 17806 / 18148 | 15974 / 16416 | 41256 / 41261 | 33522 / 32813 | 105671 / 105997 | 23184 / 22630 | 35395 / 34919 | 39129 / 39222 | 22809 / 23059 | 265697 / 266170 | 1262 / 1259 | 7744 / 7906 | 23510 / 23346 | 29551 / 30068 | 19341 / 19149 | 23641 / 23196 | 23053 / 17621 | 33240 / 24104 | 51035 / 41690 | 21945 / 22184 |
| 5 | 3776 | 0 | 3776 (0.3% unmoved) | 3776 (17.5% unmoved) | 67 | 63 | 5976 / 5990 | 6006 / 6011 | 6019 / 6032 | 10476 / 10523 | 6219 / 6143 | 35319 / 34696 | 44466 / 44332 | 15023 / 15193 | 20359 / 20338 | 25025 / 25596 | 17750 / 18053 | 15941 / 16297 | 41036 / 41425 | 33161 / 33384 | 106589 / 105245 | 23149 / 23235 | 34622 / 34804 | 39223 / 38982 | 22873 / 22922 | 266235 / 266161 | 1295 / 1249 | 7707 / 7697 | 23232 / 23438 | 29552 / 29509 | 19378 / 19212 | 23315 / 23172 | 23335 / 23577 | 33123 / 33873 | 51213 / 51037 | 22409 / 21821 |
| 6 | 2268 | 0 | 2268 (0.3% unmoved) | 2256 (17.5% unmoved) | 69 | 39 | 6016 / 5968 | 5997 / 5984 | 5981 / 6008 | 10876 / 10617 | 6159 / 6042 | 34209 / 34842 | 44068 / 44342 | 15429 / 15169 | 20351 / 19914 | 25582 / 25672 | 18288 / 18086 | 15848 / 16363 | 41136 / 41190 | 32917 / 32720 | 105921 / 106014 | 22887 / 22904 | 35055 / 35357 | 39220 / 39146 | 22833 / 22955 | 266777 / 265967 | 1262 / 1262 | 7734 / 7767 | 23368 / 23171 | 29523 / 29929 | 19510 / 19367 | 23706 / 23276 | 18385 / 16395 | 25301 / 22816 | 42785 / 39326 | 21977 / 21851 |
| 7 | 696 | 0 | 696 (0.3% unmoved) | 688 (17.5% unmoved) | 99 | 64 | 6044 / 5980 | 6028 / 5983 | 6006 / 6028 | 10688 / 10695 | 6008 / 6080 | 34739 / 35550 | 44558 / 44118 | 15822 / 14998 | 20689 / 20214 | 24979 / 25243 | 18023 / 17688 | 16201 / 16389 | 41142 / 41245 | 33384 / 33299 | 105853 / 105315 | 23113 / 23309 | 34992 / 34880 | 39085 / 38968 | 22817 / 22877 | 264833 / 266381 | 1307 / 1245 | 7949 / 7872 | 23472 / 23447 | 29669 / 29452 | 19307 / 19204 | 23172 / 23109 | 23632 / 23124 | 33650 / 33356 | 51518 / 51759 | 22144 / 22343 |
| 8 | 3220 | 0 | 3220 (0.3% unmoved) | 3216 (17.5% unmoved) | 72 | 63 | | | | 10459 / 10479 | 6014 / 6005 | 33981 / 34228 | | 15628 / 15206 | 20468 / 19798 | 25852 / 24869 | 17933 / 17330 | 16140 / 16099 | | 32892 / 32856 | | 23288 / 22713 | | | | | 1276 / 1242 | 7733 / 7910 | | | | | 23419 / 24069 | 33785 / 33339 | 51370 / 51315 | 22028 / 22317 |
| 9 | 1712 | 0 | 1712 (0.3% unmoved) | 1712 (17.5% unmoved) | 77 | 58 | | | | 10507 / 10561 | 6078 / 6021 | 35926 / 33752 | | 15382 / 15247 | 20120 / 20617 | 25510 / 25633 | 18100 / 17747 | 16093 / 16338 | | 33218 / 32657 | | 23393 / 22926 | | | | | 1277 / 1284 | 7816 / 7773 | | | | | 23013 / 16993 | 33064 / 23587 | 51126 / 39932 | 22055 / 21967 |
| 10 | 76 | 0 | 76 (0.3% unmoved) | 64 (17.5% unmoved) | 81 | 62 | | | | 10539 / 10473 | 5997 / 6008 | 34493 / 34506 | | 15478 / 15173 | 19873 / 20135 | 25683 / 24523 | 17782 / 17777 | 15910 / 16439 | | 32806 / 32522 | | 22903 / 22651 | | | | | 1282 / 1300 | 7720 / 8049 | | | | | 16647 / 23110 | 22362 / 33243 | 38718 / 51060 | 22068 / 21901 |
| 11 | 2664 | 0 | 2664 (0.3% unmoved) | 2656 (17.5% unmoved) | 78 | 45 | | | | 10483 / 10536 | 5975 / 5987 | 34330 / 33791 | | 15907 / 15029 | 20536 / 20256 | 25621 / 24991 | 17331 / 17482 | 16074 / 16469 | | 33397 / 32339 | | 23124 / 23301 | | | | | 1280 / 1265 | 8003 / 8052 | | | | | 23061 / 23130 | 33089 / 33002 | 50757 / 50995 | 22038 / 21900 |
| 12 | 1028 | 0 | 1028 (0.3% unmoved) | 1024 (17.5% unmoved) | 105 | 49 | | | | | | 34898 / 34607 | | | 20530 / 20715 | 25580 / 25100 | 17460 / 18080 | | | 33019 / 32811 | | | | | | | 1272 / 1251 | | | | | | 16495 / 23298 | 22725 / 33278 | 39867 / 51617 | |
| 13 | 3616 | 0 | 3616 (0.3% unmoved) | 3616 (17.5% unmoved) | 86 | 56 | | | | | | 34500 / 35293 | | | 20239 / 19855 | 24522 / 25084 | 17366 / 17526 | | | 32356 / 32742 | | | | | | | 1258 / 1254 | | | | | | 23264 / 23097 | 33257 / 33332 | 51216 / 51050 | |
| 14 | 2044 | 0 | 2044 (0.3% unmoved) | 2032 (17.5% unmoved) | 74 | 60 | | | | | | 35193 / 34196 | | | 20469 / 20240 | 24903 / 24978 | 17916 / 18175 | | | 33211 / 32851 | | | | | | | 1274 / 1241 | | | | | | 23469 / 23056 | 33429 / 33257 | 51240 / 51310 | |
| 15 | 472 | 0 | 472 (0.3% unmoved) | 464 (17.5% unmoved) | 100 | 42 | | | | | | 34024 / 34559 | | | 20072 / 19997 | 24647 / 25754 | 17885 / 17661 | | | 33331 / 32575 | | | | | | | 1251 / 1246 | | | | | | 22971 / 16335 | 33185 / 22294 | 50912 / 38777 | |
| 16 | 2996 | 0 | 2996 (0.3% unmoved) | 2992 (17.5% unmoved) | 88 | 41 | | | | | | 34240 / 34151 | | | | 25315 / 24833 | 17679 / 18017 | | | | | | | | | | | | | | | | 23120 / 16360 | 33485 / 22493 | 51269 / 39499 | |
| 17 | 1424 | 0 | 1424 (0.3% unmoved) | 1424 (17.5% unmoved) | 69 | 59 | | | | | | 34119 / 34692 | | | | 24989 / 24351 | 18447 / 17365 | | | | | | | | | | | | | | | | 23070 / 23872 | 33252 / 33676 | 51001 / 52112 | |
| 18 | 4012 | 0 | 4012 (0.3% unmoved) | 4000 (17.5% unmoved) | 85 | 53 | | | | | | 34704 / 34709 | | | | 25335 / 25219 | 17893 / 17270 | | | | | | | | | | | | | | | | 16829 / 22935 | 23200 / 33403 | 38968 / 51045 | |
| 19 | 2376 | 0 | 2376 (0.3% unmoved) | 2368 (17.5% unmoved) | 76 | 38 | | | | | | 34370 / 33828 | | | | 24632 / 24828 | 18206 / 17754 | | | | | | | | | | | | | | | | 23269 / 17327 | 33364 / 23600 | 51257 / 38999 | |
| 20 | 868 | 0 | 868 (0.3% unmoved) | 864 (17.5% unmoved) | 89 | 61 | | | | | | | | | | 25120 / 25688 | | | | | | | | | | | | | | | | | 16691 / 19251 | 22618 / 26790 | 38724 / 43622 | |
| 21 | 3328 | 0 | 3328 (0.3% unmoved) | 3328 (17.5% unmoved) | 70 | 40 | | | | | | | | | | 24981 / 24917 | | | | | | | | | | | | | | | | | 16419 / 22879 | 22629 / 33182 | 39910 / 51476 | |
| 22 | 1820 | 0 | 1820 (0.3% unmoved) | 1808 (17.5% unmoved) | 74 | 57 | | | | | | | | | | 25228 / 25198 | | | | | | | | | | | | | | | | | 17470 / 13592 | 23118 / 18839 | 40066 / 34959 | |
| 23 | 248 | 0 | 248 (0.3% unmoved) | 240 (17.5% unmoved) | 73 | 48 | | | | | | | | | | 24934 / 24771 | | | | | | | | | | | | | | | | | 23022 / 14856 | 33131 / 20783 | 51004 / 36792 | |
| stock | - | - | 4092 (0.1% unmoved) | 4080 (17.4% unmoved) | 79 | 57 | 5990 / 5975 | 6001 / 5968 | 6023 / 6003 | 10576 / 10908 | 6214 / 5987 | 34066 / 34693 | 44947 / 44451 | 15503 / 15248 | 20374 / 20530 | 25528 / 25659 | 17862 / 17836 | 16086 / 16042 | 41239 / 41453 | 33922 / 32859 | 106175 / 105308 | 23251 / 23215 | 34966 / 35645 | 39647 / 39918 | 22913 / 22863 | 266700 / 266155 | 1243 / 1258 | 7732 / 7733 | 23292 / 23122 | 29392 / 29578 | 19364 / 19981 | 23118 / 23221 | 23071 / 21203 | 33194 / 28474 | 51407 / 44739 | 22455 / 21988 |

Batches (variants, cases timed): 8 x 30, 12 x 16, 16 x 9, 20 x 6, 24 x 4; variants per case: 8: 14, 12: 7, 16: 3, 20: 2, 24: 4.
Builds and checks 390 s; timings 661 s (1220 runs); load 2.90, 3.29, 2.92, 3.50, 2.85, 3.04, 2.94, 2.98, 2.97, 2.85 (start and end of each batch).

</details>

Raw timings: `/private/tmp/claude-501/-Users-dave-work-ngn-k-k/eb2f95d5-4068-4d95-8225-d12e510d750c/scratchpad/ld/lv/raw/20261004-174330.json`.

