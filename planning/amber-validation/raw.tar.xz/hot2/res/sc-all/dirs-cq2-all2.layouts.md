# Layout timings: `/private/tmp/claude-501/-Users-dave-work-ngn-k-k/eb2f95d5-4068-4d95-8225-d12e510d750c/scratchpad/hot2/all2` against `/private/tmp/claude-501/-Users-dave-work-ngn-k-k/eb2f95d5-4068-4d95-8225-d12e510d750c/scratchpad/col/cq2`

## Layout-randomised timings (designed: code and data)

Each case re-timed across designed variants of base and of branch (pbt/ldesign.py, seed 0). Variant i has pad i
(an unused function at the top of `src/0.c`) and no data hook (--no-data). Base and branch of a variant run back
to back (random order), 7 rounds after a first run of each; the stock (unpadded, unhooked) builds as one more
pair in the first batch (Stock layout; ** when measurable), and variant 0 again in each later batch (an anchor).
Adaptive: 8 variants, then 4 more at a time while the interval is wider than +-1.0%, up to 24.

Change: geometric mean of the per-variant median paired ratios branch/base (per pad first), with a t interval
over the pads (pads - 1 df). Code: the range of the stock-data variants' medians (base / branch; later batches
scaled by their anchor), the slowest against their median (the worse version), and the case's p-value (labels
permuted within a batch's rounds, statistic the within-batch sum of squares of trimmed means; the smaller of
base's and branch's, doubled). **code** / **data**: significant after Benjamini-Hochberg across the cases (q =
0.05), p <= 0.01, and over the threshold (3%, 10% under 5 ms). Spread: the range of all variant medians.
Verdict: **change** when the interval excludes no change and the change is over the threshold; otherwise
placement when the stock change is measurable or the case is flagged; noise otherwise. Attributed "stock code
layout": the stock pair's change is measurable and its interval misses the stock-data variants' (they differ
from it in code only: no pad, no hook, the same data placement).

Flagged (of 3 cases): code 0, data 0, run 0; change 3; stock code layout 0; intervals containing no change: 0.

| Case | Stock layout | Layout-averaged change | 95% interval | K | Code | Spread | Run | Attributed | Verdict |
|---|---|---|---|---|---|---|---|---|---|
| `grpsc.k: sc_group_10` | -46.1% (-47.4% to -45.6%) ** | -47.3% | -47.6% to -47.0% | 8 | 2.0% / 2.0%, worst +1.4% (p 0.22) | 2.0% / 2.0% | (p 1) | - | **change** |
| `grpsc.k: sc_group_10k` | -36.8% (-37.4% to -36.3%) ** | -36.0% | -36.5% to -35.4% | 8 | 2.7% / 2.4%, worst +1.9% (p 0.75) | 2.7% / 2.4% | (p 1) | - | **change** |
| `grpsc.k: sc_group_100k` | -27.1% (-27.7% to -26.7%) ** | -27.7% | -28.1% to -27.3% | 8 | 2.5% / 2.9%, worst +1.8% (p 0.24) | 2.5% / 2.9% | (p 1) | - | **change** |

<details><summary>Design and variants</summary>

8 pads: 364, 696, 1316, 1872, 2268, 2824, 3508, 3776; largest gap mod 4096 684 B (even: 512); 8 of 16 phases mod 64, 4 of 4 mod 16.

Shift: the most common move of a function against the pad-0 variant build (mod 4096) and the share of
functions not moved (an order file's pinned region); Loops: small loops straddling a 4 KB boundary.

| Variant | Pad | Colour | Base shift | Branch shift | Base loops | Branch loops | grpsc.k: sc_group_10 base / branch | grpsc.k: sc_group_10k base / branch | grpsc.k: sc_group_100k base / branch |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 3508 | 0 | 3504 (17.4% unmoved) | 3504 (17.4% unmoved) | 63 | 60 | 34857 / 18618 | 43884 / 27755 | 42784 / 31182 |
| 1 | 1872 | 0 | 1872 (17.4% unmoved) | 1872 (17.4% unmoved) | 55 | 51 | 35037 / 18594 | 44405 / 27666 | 42389 / 30650 |
| 2 | 364 | 0 | 352 (17.4% unmoved) | 352 (17.4% unmoved) | 51 | 45 | 34797 / 18420 | 43231 / 27685 | 43019 / 30768 |
| 3 | 2824 | 0 | 2816 (17.4% unmoved) | 2816 (17.4% unmoved) | 52 | 57 | 35034 / 18530 | 43937 / 28112 | 42927 / 30922 |
| 4 | 1316 | 0 | 1312 (17.4% unmoved) | 1312 (17.4% unmoved) | 67 | 72 | 35397 / 18389 | 43507 / 27762 | 42623 / 31187 |
| 5 | 3776 | 0 | 3776 (17.4% unmoved) | 3776 (17.4% unmoved) | 66 | 74 | 35153 / 18239 | 43812 / 27856 | 42504 / 31562 |
| 6 | 2268 | 0 | 2256 (17.4% unmoved) | 2256 (17.4% unmoved) | 36 | 47 | 34869 / 18451 | 43661 / 28279 | 43464 / 31414 |
| 7 | 696 | 0 | 688 (17.4% unmoved) | 688 (17.4% unmoved) | 83 | 77 | 35514 / 18577 | 43461 / 28335 | 42429 / 30698 |
| stock | - | - | 4080 (17.3% unmoved) | 4080 (17.3% unmoved) | 48 | 52 | 34968 / 18853 | 44145 / 27840 | 42131 / 30735 |

Batches (variants, cases timed): 8 x 3; variants per case: 8: 3.
Builds and checks 0 s; timings 24 s (145 runs); load 1.91, 2.03 (start and end of each batch).

</details>

Raw timings: `/private/tmp/claude-501/-Users-dave-work-ngn-k-k/eb2f95d5-4068-4d95-8225-d12e510d750c/scratchpad/hot2/lv/raw/20261005-020756.json`.

