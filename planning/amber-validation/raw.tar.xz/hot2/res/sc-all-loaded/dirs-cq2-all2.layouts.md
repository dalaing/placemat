# Layout timings: `/private/tmp/claude-501/-Users-dave-work-ngn-k-k/eb2f95d5-4068-4d95-8225-d12e510d750c/scratchpad/hot2/all2` against `/private/tmp/claude-501/-Users-dave-work-ngn-k-k/eb2f95d5-4068-4d95-8225-d12e510d750c/scratchpad/col/cq2`

## Layout-randomised timings (designed: code and data)

Each case re-timed across designed variants of base and of branch (pbt/ldesign.py, seed 0). Variant i has pad i
(an unused function at the top of `src/0.c`) and no data hook (--no-data). Base and branch of a variant run back
to back (random order), 7 rounds after a first run of each; the stock (unpadded, unhooked) builds as one more
pair in the first batch (Stock layout; ** when measurable), and variant 0 again in each later batch (an anchor).
Adaptive: 8 variants, then 4 more at a time while the interval is wider than +-1.0%, up to 24.

Change: geometric mean of the per-variant median paired ratios branch/base (per pad first), with a t interval
over the pads (pads - 1 df). Code: the range of the stock-data variants' medians (base / branch; later batches
scaled by their anchor), the slowest against their median (the worse version), and the case's p-value (labels
permuted within a batch's rounds, statistic the within-batch sum of squares of trimmed means; the smaller of
base's and branch's, doubled). **code** / **data**: significant after Benjamini-Hochberg across the cases (q =
0.05), p <= 0.01, and over the threshold (3%, 10% under 5 ms). Spread: the range of all variant medians.
Verdict: **change** when the interval excludes no change and the change is over the threshold; otherwise
placement when the stock change is measurable or the case is flagged; noise otherwise. Attributed "stock code
layout": the stock pair's change is measurable and its interval misses the stock-data variants' (they differ
from it in code only: no pad, no hook, the same data placement).

Flagged (of 3 cases): code 0, data 0, run 0; change 3; stock code layout 0; intervals containing no change: 0.

| Case | Stock layout | Layout-averaged change | 95% interval | K | Code | Spread | Run | Attributed | Verdict |
|---|---|---|---|---|---|---|---|---|---|
| `grpsc.k: sc_group_10` | -46.7% (-47.8% to -44.9%) ** | -47.2% | -47.6% to -46.8% | 8 | 3.0% / 3.2%, worst +2.6% (p 0.27) | 3.0% / 3.2% | (p 1) | - | **change** |
| `grpsc.k: sc_group_10k` | -36.0% (-36.3% to -35.3%) ** | -36.2% | -36.6% to -35.7% | 8 | 2.6% / 3.4%, worst +2.9% (p 0.093) | 2.6% / 3.4% | (p 1) | - | **change** |
| `grpsc.k: sc_group_100k` | -27.3% (-28.5% to -26.4%) ** | -27.4% | -27.9% to -26.9% | 12 | 3.0% / 4.1%, worst +2.8% (p 0.19) | 3.0% / 4.1% | (p 1) | - | **change** |

<details><summary>Design and variants</summary>

12 pads: 76, 364, 696, 1316, 1712, 1872, 2268, 2664, 2824, 3220, 3508, 3776; largest gap mod 4096 620 B (even: 341); 12 of 16 phases mod 64, 4 of 4 mod 16.

Shift: the most common move of a function against the pad-0 variant build (mod 4096) and the share of
functions not moved (an order file's pinned region); Loops: small loops straddling a 4 KB boundary.

| Variant | Pad | Colour | Base shift | Branch shift | Base loops | Branch loops | grpsc.k: sc_group_10 base / branch | grpsc.k: sc_group_10k base / branch | grpsc.k: sc_group_100k base / branch |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 3508 | 0 | 3504 (17.4% unmoved) | 3504 (17.4% unmoved) | 63 | 60 | 34759 / 18440 | 44511 / 28563 | 42558 / 30625 |
| 1 | 1872 | 0 | 1872 (17.4% unmoved) | 1872 (17.4% unmoved) | 55 | 51 | 35621 / 18709 | 43633 / 28189 | 42504 / 31594 |
| 2 | 364 | 0 | 352 (17.4% unmoved) | 352 (17.4% unmoved) | 51 | 45 | 34874 / 18446 | 44405 / 27764 | 42727 / 30784 |
| 3 | 2824 | 0 | 2816 (17.4% unmoved) | 2816 (17.4% unmoved) | 52 | 57 | 35810 / 18892 | 43732 / 27771 | 42544 / 30766 |
| 4 | 1316 | 0 | 1312 (17.4% unmoved) | 1312 (17.4% unmoved) | 67 | 72 | 34908 / 18294 | 43630 / 28155 | 43148 / 30672 |
| 5 | 3776 | 0 | 3776 (17.4% unmoved) | 3776 (17.4% unmoved) | 66 | 74 | 34852 / 18316 | 43772 / 27616 | 42551 / 31011 |
| 6 | 2268 | 0 | 2256 (17.4% unmoved) | 2256 (17.4% unmoved) | 36 | 47 | 34856 / 18412 | 43374 / 27697 | 43343 / 31114 |
| 7 | 696 | 0 | 688 (17.4% unmoved) | 688 (17.4% unmoved) | 83 | 77 | 35076 / 18774 | 44398 / 27640 | 42276 / 30779 |
| 8 | 3220 | 0 | 3216 (17.4% unmoved) | 3216 (17.4% unmoved) | 60 | 65 | | | 42501 / 31094 |
| 9 | 1712 | 0 | 1712 (17.4% unmoved) | 1712 (17.4% unmoved) | 61 | 67 | | | 43265 / 31106 |
| 10 | 76 | 0 | 64 (17.4% unmoved) | 64 (17.4% unmoved) | 60 | 57 | | | 42363 / 31040 |
| 11 | 2664 | 0 | 2656 (17.4% unmoved) | 2656 (17.4% unmoved) | 48 | 48 | | | 43166 / 30903 |
| stock | - | - | 4080 (17.3% unmoved) | 4080 (17.3% unmoved) | 48 | 52 | 35111 / 18508 | 43574 / 27868 | 42572 / 31190 |

Batches (variants, cases timed): 8 x 3, 12 x 1; variants per case: 8: 2, 12: 1.
Builds and checks 0 s; timings 109 s (225 runs); load 2.27, 6.67, 2.98, 2.83 (start and end of each batch).

</details>

Raw timings: `/private/tmp/claude-501/-Users-dave-work-ngn-k-k/eb2f95d5-4068-4d95-8225-d12e510d750c/scratchpad/hot2/lv/raw/20261005-020644.json`.

