# Layout timings: `/private/tmp/claude-501/-Users-dave-work-ngn-k-k/eb2f95d5-4068-4d95-8225-d12e510d750c/scratchpad/col/py` against `/private/tmp/claude-501/-Users-dave-work-ngn-k-k/eb2f95d5-4068-4d95-8225-d12e510d750c/scratchpad/of/A`

## Layout-randomised timings (designed: code and data)

Each case re-timed across designed variants of base and of branch (pbt/ldesign.py, seed 0). Variant i has pad i
(an unused function at the top of `src/0.c`) and no data hook (--no-data). Base and branch of a variant run back
to back (random order), 7 rounds after a first run of each; the stock (unpadded, unhooked) builds as one more
pair in the first batch (Stock layout; ** when measurable), and variant 0 again in each later batch (an anchor).
Adaptive: 8 variants, then 4 more at a time while the interval is wider than +-1.0%, up to 24.

Change: geometric mean of the per-variant median paired ratios branch/base (per pad first), with a t interval
over the pads (pads - 1 df). Code: the range of the stock-data variants' medians (base / branch; later batches
scaled by their anchor), the slowest against their median (the worse version), and the case's p-value (labels
permuted within a batch's rounds, statistic the within-batch sum of squares of trimmed means; the smaller of
base's and branch's, doubled). **code** / **data**: significant after Benjamini-Hochberg across the cases (q =
0.05), p <= 0.01, and over the threshold (3%, 10% under 5 ms). Spread: the range of all variant medians.
Verdict: **change** when the interval excludes no change and the change is over the threshold; otherwise
placement when the stock change is measurable or the case is flagged; noise otherwise. Attributed "stock code
layout": the stock pair's change is measurable and its interval misses the stock-data variants' (they differ
from it in code only: no pad, no hook, the same data placement).

Flagged (of 28 cases): code 6, data 0, run 0; change 7; stock code layout 6; intervals containing no change: 6.

| Case | Stock layout | Layout-averaged change | 95% interval | K | Code | Spread | Run | Attributed | Verdict |
|---|---|---|---|---|---|---|---|---|---|
| `microbench: jsonints` (series) | +11.9% (+7.8% to +13.7%) ** | +4.3% | +3.4% to +5.2% | 8 | 3.8% / 3.3%, worst +2.4% (p 0.47) | 3.8% / 3.3% | (p 1) | stock code layout | **change** |
| `microbench: jsonshort` (series) | +9.8% (+8.6% to +10.1%) ** | +4.0% | +3.1% to +4.9% | 24 | 8.4% / 7.8%, worst +7.5% (p 0.0008) **code** | 8.4% / 7.8% | (p 1) | code+stock code layout | **change** |
| `microbench: dictplus` (series) | +5.7% (+4.4% to +6.9%) ** | +5.4% | +4.5% to +6.4% | 24 | 9.5% / 5.5%, worst +5.1% (p 0.0001) **code** | 9.5% / 5.5% | (p 1) | code | **change** |
| `microbench: jsonread17` | +2.2% (+1.3% to +2.7%) | +1.9% | +1.1% to +2.7% | 8 | 2.2% / 2.2%, worst +1.2% (p 1) | 2.2% / 2.2% | (p 1) | - | noise |
| `microbench: chardivfold` (series) | +14.0% (+9.2% to +14.5%) ** | +8.5% | +7.7% to +9.3% | 12 | 3.0% / 3.7%, worst +1.1% (p 0.081) | 3.0% / 3.7% | (p 1) | - | **change** |
| `microbench: fparse17` | +8.1% (+7.0% to +10.4%) ** | +2.8% | +2.0% to +3.6% | 8 | 2.1% / 2.3%, worst +1.2% (p 0.16) | 2.1% / 2.3% | (p 1) | stock code layout | placement |
| `microbench: flitstrand` (series) | +0.4% (-3.9% to +1.2%) | +0.4% | -0.9% to +1.7% | 24 | 8.6% / 10.8%, worst +8.7% (p 0.0001) **code** | 8.6% / 10.8% | (p 1) | code | placement |
| `microbench: setdictkeys` (series) | +1.6% (-0.1% to +3.7%) | +2.1% | +1.7% to +2.6% | 8 | 1.3% / 1.9%, worst +0.7% (p 1) | 1.3% / 1.9% | (p 1) | - | noise |
| `microbench: jsonread` (series) | +8.2% (+5.7% to +9.0%) ** | +2.5% | +1.7% to +3.4% | 8 | 2.3% / 2.8%, worst +1.8% (p 0.5) | 2.3% / 2.8% | (p 1) | stock code layout | placement |
| `microbench: fparsemany` | +6.3% (+4.1% to +8.6%) ** | +2.9% | +2.0% to +3.7% | 20 | 6.9% / 8.5%, worst +5.6% (p 0.29) | 6.9% / 8.5% | (p 1) | stock code layout | placement |
| `microbench: genericdistinct` (series) | +0.7% (+0.3% to +1.7%) | +1.1% | +0.8% to +1.5% | 8 | 0.8% / 1.2%, worst +0.6% (p 0.036) | 0.8% / 1.2% | (p 1) | - | noise |
| `microbench: charltscan` | +1.5% (+0.8% to +1.8%) | -0.0% | -0.2% to +0.1% | 8 | 0.2% / 0.3%, worst +0.1% (p 0.78) | 0.2% / 0.3% | (p 1) | - | noise |
| `microbench: settablekeys` (series) | +1.2% (+0.8% to +1.9%) | +1.6% | +0.9% to +2.3% | 8 | 2.7% / 1.6%, worst +1.8% (p 0.0001) | 2.7% / 1.6% | (p 1) | - | noise |
| `microbench: setdictdictfan` (series) | +2.5% (+2.4% to +3.0%) | +1.5% | +0.7% to +2.3% | 8 | 3.8% / 1.4%, worst +3.2% (p 0.0001) **code** | 3.8% / 1.4% | (p 1) | code | placement |
| `microbench: tillists` (series) | +1.7% (+0.8% to +2.5%) | +2.7% | +2.0% to +3.5% | 8 | 2.5% / 3.1%, worst +1.6% (p 0.082) | 2.5% / 3.1% | (p 1) | - | noise |
| `microbench: takecols` (series) | -0.1% (-0.8% to +2.4%) | +2.1% | +1.4% to +2.8% | 12 | 2.8% / 2.4%, worst +1.7% (p 0.091) | 2.8% / 2.4% | (p 1) | - | noise |
| `microbench: takekeys10x1` (series) | +2.5% (+0.0% to +2.8%) | +1.6% | +0.9% to +2.2% | 8 | 2.2% / 1.6%, worst +0.8% (p 0.75) | 2.2% / 1.6% | (p 1) | - | noise |
| `microbench: setlistdictall` (series) | +2.1% (+1.1% to +2.2%) | +1.8% | +1.3% to +2.4% | 8 | 2.5% / 1.8%, worst +1.6% (p 0.0001) | 2.5% / 1.8% | (p 1) | - | noise |
| `microbench: setflatverb` (series) | +1.7% (-0.2% to +2.9%) | +1.7% | +1.3% to +2.0% | 8 | 2.6% / 2.3%, worst +2.4% (p 1) | 2.6% / 2.3% | (p 1) | - | noise |
| `microbench: settableverb` (series) | +0.2% (-2.2% to +1.6%) | +0.5% | -0.5% to +1.5% | 12 | 5.5% / 5.6%, worst +3.1% (p 0.1) | 5.5% / 5.6% | (p 1) | - | noise |
| `microbench: eachenum` | +5.0% (+4.6% to +6.8%) ** | -0.1% | -1.1% to +0.9% | 12 | 4.4% / 2.5%, worst +3.1% (p 0.001) **code** | 4.4% / 2.5% | (p 1) | code+stock code layout | placement |
| `microbench: setflat` (series) | +1.4% (-1.3% to +3.2%) | +1.4% | +0.5% to +2.3% | 12 | 2.8% / 4.0%, worst +3.2% (p 1) | 2.8% / 4.0% | (p 1) | - | noise |
| `microbench-q: qhhatom` (series) | +1.6% (+0.1% to +1.8%) | +3.6% | +2.9% to +4.3% | 12 | 2.3% / 4.2%, worst +1.6% (p 0.033) | 2.3% / 4.2% | (p 1) | - | **change** |
| `microbench-q: qhhtime` (series) | -0.9% (-2.2% to +0.8%) | +1.5% | +0.8% to +2.2% | 8 | 3.2% / 3.0%, worst +2.4% (p 0.003) **code** | 3.2% / 3.0% | (p 1) | code | placement |
| `microbench-q: qgroup` | -0.5% (-1.0% to +1.4%) | -0.3% | -0.7% to +0.2% | 8 | 1.7% / 1.7%, worst +1.1% (p 0.66) | 1.7% / 1.7% | (p 1) | - | noise |
| `win.k: s_msum100` | -4.4% (-11.5% to +26.1%) | +5.5% | +0.4% to +10.9% | 24 | 67.5% / 75.7%, worst +38.5% (p 0.87) | 67.5% / 75.7% | (p 1) | - | **change** |
| `win.k: s_mavg100` | -0.7% (-17.4% to +29.3%) | +6.5% | +0.8% to +12.5% | 24 | 78.7% / 83.0%, worst +45.7% (p 0.81) | 78.7% / 83.0% | (p 1) | - | **change** |
| `red.k: f_min_int20m` | -4.6% (-11.8% to +1.2%) | -0.5% | -2.1% to +1.2% | 24 | 20.0% / 14.7%, worst +12.6% (p 0.31) | 20.0% / 14.7% | (p 1) | - | noise |

<details><summary>Design and variants</summary>

24 pads: 76, 248, 364, 472, 696, 868, 1028, 1316, 1424, 1712, 1820, 1872, 2044, 2268, 2376, 2664, 2824, 2996, 3220, 3328, 3508, 3616, 3776, 4012; largest gap mod 4096 288 B (even: 170); 16 of 16 phases mod 64, 4 of 4 mod 16.

Shift: the most common move of a function against the pad-0 variant build (mod 4096) and the share of
functions not moved (an order file's pinned region); Loops: small loops straddling a 4 KB boundary.

| Variant | Pad | Colour | Base shift | Branch shift | Base loops | Branch loops | microbench: jsonints base / branch | microbench: jsonshort base / branch | microbench: dictplus base / branch | microbench: jsonread17 base / branch | microbench: chardivfold base / branch | microbench: fparse17 base / branch | microbench: flitstrand base / branch | microbench: setdictkeys base / branch | microbench: jsonread base / branch | microbench: fparsemany base / branch | microbench: genericdistinct base / branch | microbench: charltscan base / branch | microbench: settablekeys base / branch | microbench: setdictdictfan base / branch | microbench: tillists base / branch | microbench: takecols base / branch | microbench: takekeys10x1 base / branch | microbench: setlistdictall base / branch | microbench: setflatverb base / branch | microbench: settableverb base / branch | microbench: eachenum base / branch | microbench: setflat base / branch | microbench-q: qhhatom base / branch | microbench-q: qhhtime base / branch | microbench-q: qgroup base / branch | win.k: s_msum100 base / branch | win.k: s_mavg100 base / branch | red.k: f_min_int20m base / branch |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | 3508 | 0 | 3508 (0.3% unmoved) | 3508 (0.3% unmoved) | 94 | 96 | 7984 / 8243 | 8434 / 8899 | 15841 / 16748 | 76908 / 78028 | 19191 / 20867 | 27997 / 29131 | 11326 / 11429 | 54302 / 55887 | 20746 / 21334 | 76759 / 80731 | 105859 / 107360 | 411115 / 411758 | 124385 / 126709 | 164428 / 167454 | 16073 / 16364 | 41114 / 42142 | 36379 / 37378 | 111262 / 114211 | 17071 / 17247 | 23030 / 23019 | 24526 / 24586 | 14243 / 14845 | 28712 / 29934 | 29884 / 30322 | 36302 / 36521 | 17109 / 22972 | 23069 / 33129 | 1651 / 1801 |
| 1 | 1872 | 0 | 1872 (0.3% unmoved) | 1872 (0.3% unmoved) | 85 | 86 | 7798 / 8266 | 8427 / 8780 | 16136 / 16834 | 75450 / 77905 | 18737 / 20758 | 28323 / 29025 | 11476 / 11652 | 54273 / 55772 | 20631 / 21331 | 78535 / 79285 | 106468 / 107366 | 412055 / 411751 | 123217 / 126518 | 163413 / 167777 | 16110 / 16286 | 41512 / 41634 | 37037 / 37579 | 111546 / 113600 | 17004 / 17391 | 23627 / 23344 | 24839 / 24649 | 14501 / 14715 | 28365 / 29915 | 29591 / 30057 | 36174 / 35910 | 23439 / 23181 | 33067 / 33408 | 1687 / 1718 |
| 2 | 364 | 0 | 364 (0.3% unmoved) | 364 (0.3% unmoved) | 82 | 85 | 7778 / 8097 | 8474 / 8737 | 15928 / 16486 | 75218 / 76986 | 19099 / 20223 | 28590 / 28759 | 11389 / 12317 | 54194 / 55590 | 20731 / 21158 | 77345 / 81958 | 105623 / 106446 | 411551 / 411550 | 125393 / 126180 | 164338 / 166622 | 16170 / 16465 | 41011 / 41932 | 37067 / 37005 | 110997 / 113453 | 16926 / 16989 | 22453 / 22774 | 24786 / 24446 | 14549 / 14640 | 28531 / 29354 | 29836 / 29918 | 36391 / 35965 | 23301 / 23255 | 33612 / 33764 | 1790 / 1781 |
| 3 | 2824 | 0 | 2824 (0.3% unmoved) | 2824 (0.3% unmoved) | 98 | 85 | 7794 / 8022 | 8420 / 8812 | 15920 / 16859 | 75859 / 77219 | 19053 / 20924 | 28599 / 29237 | 11412 / 11416 | 54678 / 55713 | 20777 / 20989 | 78917 / 79572 | 106171 / 106857 | 411223 / 411431 | 123559 / 126167 | 169659 / 168863 | 16290 / 16752 | 42038 / 42551 | 37192 / 37293 | 113126 / 113349 | 17357 / 17031 | 22928 / 23323 | 24628 / 24857 | 14501 / 14601 | 28288 / 29875 | 29532 / 30309 | 36064 / 36303 | 23406 / 16631 | 33566 / 22905 | 1688 / 1731 |
| 4 | 1316 | 0 | 1316 (0.3% unmoved) | 1316 (0.3% unmoved) | 91 | 77 | 7796 / 8078 | 8661 / 8888 | 16036 / 17184 | 76076 / 76944 | 19247 / 20602 | 28393 / 29292 | 11557 / 11762 | 54409 / 55737 | 20683 / 21134 | 78743 / 81017 | 106397 / 107724 | 411485 / 412002 | 124729 / 126900 | 164837 / 167778 | 16270 / 16587 | 41367 / 42342 | 36805 / 37487 | 111699 / 113778 | 16937 / 17162 | 23136 / 23646 | 24635 / 24830 | 14609 / 14649 | 28521 / 29737 | 29949 / 29970 | 36400 / 36085 | 23037 / 22926 | 33248 / 33162 | 1751 / 1653 |
| 5 | 3776 | 0 | 3776 (0.3% unmoved) | 3776 (0.3% unmoved) | 67 | 68 | 7962 / 8114 | 8388 / 8886 | 16410 / 16959 | 76407 / 76329 | 18922 / 20931 | 27996 / 28620 | 11641 / 11480 | 53990 / 54819 | 20622 / 21168 | 78785 / 81011 | 106000 / 107663 | 411673 / 412074 | 123086 / 125799 | 163372 / 166578 | 15887 / 16248 | 40972 / 41555 | 36692 / 37449 | 110288 / 113102 | 16922 / 17154 | 23265 / 23385 | 25399 / 24419 | 14530 / 14713 | 28434 / 29611 | 29561 / 30158 | 35802 / 36159 | 17713 / 17396 | 23156 / 23981 | 1699 / 1644 |
| 6 | 2268 | 0 | 2268 (0.3% unmoved) | 2268 (0.3% unmoved) | 69 | 62 | 7686 / 8217 | 8544 / 8853 | 15858 / 16981 | 75502 / 77403 | 19032 / 20621 | 28038 / 28987 | 11315 / 12435 | 54352 / 55653 | 20790 / 21252 | 78860 / 79752 | 106108 / 106495 | 412093 / 411268 | 126235 / 126789 | 165834 / 166755 | 16083 / 16508 | 40892 / 42043 | 36387 / 36992 | 111359 / 113799 | 16966 / 17369 | 22923 / 23004 | 24408 / 24710 | 14580 / 14678 | 28624 / 29065 | 30167 / 30835 | 36159 / 36069 | 23146 / 22910 | 33240 / 33134 | 1683 / 1694 |
| 7 | 696 | 0 | 696 (0.3% unmoved) | 696 (0.3% unmoved) | 99 | 103 | 7939 / 8295 | 8618 / 9108 | 15307 / 16878 | 76599 / 77655 | 19019 / 20167 | 28206 / 29147 | 12136 / 11321 | 54235 / 55511 | 21108 / 21589 | 76566 / 79338 | 105601 / 106712 | 411679 / 410953 | 122896 / 124933 | 163482 / 166702 | 15995 / 16556 | 41267 / 41685 | 36993 / 37227 | 110680 / 112222 | 16944 / 17252 | 22590 / 22941 | 24532 / 24626 | 14448 / 14738 | 28675 / 29210 | 29206 / 29938 | 35925 / 36454 | 16492 / 23337 | 22477 / 33376 | 1717 / 1675 |
| 8 | 3220 | 0 | 3220 (0.3% unmoved) | 3220 (0.3% unmoved) | 72 | 73 | | 8451 / 8827 | 16080 / 17049 | | 19163 / 20746 | | 11743 / 11707 | | | 78481 / 79877 | | | | | | 41499 / 42539 | | | | 22971 / 23712 | 24521 / 24778 | 14491 / 14636 | 29064 / 30165 | | | 16412 / 22997 | 22319 / 33310 | 1607 / 1623 |
| 9 | 1712 | 0 | 1712 (0.3% unmoved) | 1712 (0.3% unmoved) | 77 | 76 | | 8743 / 8758 | 16043 / 16685 | | 18639 / 20423 | | 11529 / 11629 | | | 77301 / 81291 | | | | | | 40945 / 42384 | | | | 23513 / 23400 | 24855 / 24469 | 14238 / 14493 | 28409 / 29670 | | | 16235 / 23262 | 22825 / 33672 | 1653 / 1779 |
| 10 | 76 | 0 | 76 (0.3% unmoved) | 76 (0.3% unmoved) | 81 | 82 | | 8413 / 8896 | 16736 / 17023 | | 19076 / 20730 | | 11689 / 11505 | | | 78034 / 79998 | | | | | | 41835 / 42042 | | | | 23381 / 23024 | 24959 / 24957 | 14405 / 14700 | 28906 / 29981 | | | 23159 / 23179 | 33249 / 33127 | 1705 / 1667 |
| 11 | 2664 | 0 | 2664 (0.3% unmoved) | 2664 (0.3% unmoved) | 78 | 87 | | 8598 / 8833 | 15937 / 17398 | | 19075 / 20677 | | 11618 / 11422 | | | 76130 / 81214 | | | | | | 41483 / 42542 | | | | 23233 / 23148 | 24889 / 24429 | 14336 / 14940 | 28511 / 29685 | | | 23029 / 19049 | 33070 / 25947 | 1712 / 1696 |
| 12 | 1028 | 0 | 1028 (0.3% unmoved) | 1028 (0.3% unmoved) | 105 | 103 | | 8921 / 9281 | 16785 / 17456 | | | | 12098 / 11986 | | | 81339 / 83329 | | | | | | | | | | | | | | | | 23940 / 22196 | 33869 / 30827 | 1669 / 1698 |
| 13 | 3616 | 0 | 3616 (0.3% unmoved) | 3616 (0.3% unmoved) | 86 | 85 | | 8880 / 9597 | 16560 / 17827 | | | | 11975 / 12028 | | | 81572 / 85375 | | | | | | | | | | | | | | | | 16703 / 23487 | 23303 / 33130 | 1615 / 1658 |
| 14 | 2044 | 0 | 2044 (0.3% unmoved) | 2044 (0.3% unmoved) | 74 | 76 | | 9365 / 9814 | 17519 / 17867 | | | | 12378 / 11957 | | | 82707 / 86570 | | | | | | | | | | | | | | | | 17286 / 23336 | 23545 / 33805 | 1651 / 1632 |
| 15 | 472 | 0 | 472 (0.3% unmoved) | 472 (0.3% unmoved) | 100 | 108 | | 9441 / 9358 | 17284 / 18040 | | | | 12439 / 11894 | | | 81598 / 81645 | | | | | | | | | | | | | | | | 22899 / 23491 | 33799 / 33751 | 1673 / 1633 |
| 16 | 2996 | 0 | 2996 (0.3% unmoved) | 2996 (0.3% unmoved) | 88 | 85 | | 8387 / 8797 | 16153 / 17106 | | | | 11374 / 11350 | | | 78543 / 79468 | | | | | | | | | | | | | | | | 16333 / 23297 | 22280 / 33176 | 1702 / 1692 |
| 17 | 1424 | 0 | 1424 (0.3% unmoved) | 1424 (0.3% unmoved) | 69 | 79 | | 8612 / 8888 | 15983 / 16886 | | | | 11308 / 11311 | | | 78034 / 79398 | | | | | | | | | | | | | | | | 15370 / 16561 | 20902 / 22983 | 1666 / 1770 |
| 18 | 4012 | 0 | 4012 (0.3% unmoved) | 4012 (0.3% unmoved) | 85 | 83 | | 8371 / 8772 | 15982 / 16955 | | | | 11292 / 11339 | | | 78620 / 82097 | | | | | | | | | | | | | | | | 23111 / 22998 | 33214 / 33267 | 1739 / 1659 |
| 19 | 2376 | 0 | 2376 (0.3% unmoved) | 2376 (0.3% unmoved) | 76 | 82 | | 8483 / 8862 | 16114 / 17261 | | | | 11389 / 11361 | | | 76413 / 79871 | | | | | | | | | | | | | | | | 16434 / 23050 | 22328 / 33196 | 1648 / 1741 |
| 20 | 868 | 0 | 868 (0.3% unmoved) | 868 (0.3% unmoved) | 89 | 75 | | 8460 / 9044 | 16106 / 16472 | | | | 11515 / 11363 | | | | | | | | | | | | | | | | | | | 23011 / 22949 | 33225 / 33156 | 1905 / 1750 |
| 21 | 3328 | 0 | 3328 (0.3% unmoved) | 3328 (0.3% unmoved) | 70 | 71 | | 8419 / 8767 | 16117 / 17162 | | | | 11601 / 11389 | | | | | | | | | | | | | | | | | | | 22883 / 14410 | 33178 / 19985 | 1711 / 1702 |
| 22 | 1820 | 0 | 1820 (0.3% unmoved) | 1820 (0.3% unmoved) | 74 | 74 | | 8392 / 8981 | 16050 / 16918 | | | | 11586 / 11677 | | | | | | | | | | | | | | | | | | | 19345 / 23104 | 26818 / 33469 | 1643 / 1673 |
| 23 | 248 | 0 | 248 (0.3% unmoved) | 248 (0.3% unmoved) | 73 | 62 | | 8401 / 8785 | 15985 / 16986 | | | | 11357 / 11368 | | | | | | | | | | | | | | | | | | | 22941 / 16296 | 33700 / 23133 | 1664 / 1810 |
| stock | - | - | 4092 (0.1% unmoved) | 4092 (0.1% unmoved) | 79 | 82 | 7862 / 8730 | 8433 / 9289 | 16021 / 17044 | 77139 / 78302 | 19030 / 21550 | 28036 / 30277 | 11354 / 11358 | 55048 / 56304 | 21154 / 22485 | 76052 / 82518 | 105778 / 106981 | 411704 / 418000 | 125138 / 126702 | 163909 / 168275 | 16059 / 16454 | 41795 / 42022 | 36364 / 37278 | 111874 / 113667 | 17210 / 17302 | 23178 / 23208 | 24403 / 25852 | 14368 / 14629 | 29067 / 29502 | 30390 / 30202 | 36407 / 36312 | 22404 / 22355 | 31203 / 29841 | 1800 / 1654 |

Batches (variants, cases timed): 8 x 28, 12 x 13, 16 x 7, 20 x 7, 24 x 6; variants per case: 8: 15, 12: 6, 20: 1, 24: 6.
Builds and checks 201 s; timings 701 s (1620 runs); load 2.51, 2.52, 2.85, 2.77, 2.40, 2.28, 2.49, 3.32, 2.90, 3.05 (start and end of each batch).

</details>

Raw timings: `/private/tmp/claude-501/-Users-dave-work-ngn-k-k/eb2f95d5-4068-4d95-8225-d12e510d750c/scratchpad/col/lv/raw/20261004-205436.json`.

